<?php

use Core\Response;


function dd($values) {
    echo "<pre>";
    print_r($values);
    echo "</pre>";
}

function abort($code = 404) {
    http_response_code($code);

    view("{$code}.php");

    die();
}


function base_path($path) {
    return BASE_PATH . $path;
}

function view($path, $attributes = []) {
    extract($attributes);
    require base_path('app/views/' . $path);
}

function controller($path, $attributes = []) {
    extract($attributes);
    require base_path('app/controller/' . $path);
}

function router($path)
 {
    return base_path('app/router/'. $path);
 }




function authorize($condition, $status = Response::FORBIDDEN) {
    if (! $condition) {
        abort($status);
    }
}


function login($user) {
    $_SESSION['user'] = [
        'school_id'=> $user['school_id'],
        'email'=> $user['email'],
        // 'password' => $user['password'],
        'l_name'=> $user['l_name'],
        'f_name'=> $user['f_name'],
        'account_type'=> $user['account_type'],
    ];

    session_regenerate_id(true); // regenerate new SESSION ID and (true) to clear out the OLD session file
}

function logout() {
    $_SESSION = []; // Cleared, para di na ma reference ng ibang file
    session_destroy(); // Destroy the session file


    $params = session_get_cookie_params(); // Gets the information about the CURRENT COOKIE
    setcookie('PHPSESSID', '', time() - 3600, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
}
