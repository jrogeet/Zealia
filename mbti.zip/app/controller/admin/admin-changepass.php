<?php

use Model\App;
use Model\Database;
use Core\Validator;

$db = App::resolve(Database::class);

$school_id = $_POST['school_id'];

$accountInfo = $db->query('select * from accounts where school_id = :id', [
    ':id' => $school_id
])->find();


if (isset($_POST['change_pass'])) {
    $encodedAccountInfo = json_encode($accountInfo);

    view('admin/admin-changepass.view.php', [
        'student_id' => $school_id,
        'accountInfo' => $accountInfo,
        'encodedAccountInfo' => $encodedAccountInfo 
    ]);
} elseif (isset($_POST['activate'])) {
    $db->query('update accounts set account_activation_hash = null where school_id = :id', [
        ':id' => $school_id
    ]);

    header('location: /admin');
    exit();
}   






