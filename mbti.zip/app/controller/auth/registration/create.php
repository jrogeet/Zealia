<?php

view('auth/registration/create.view.php', [
    'heading' => 'Register'
]);
    


