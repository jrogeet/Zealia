<?php

     view("auth/registration/success-activation.view.php", [
         
     ]);

