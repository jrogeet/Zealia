<?php

use Model\Database;
use Model\App;

$db = App::resolve(Database::class);

$currentUser = $_SESSION['user']['school_id'];

// vvvv NAVBAR NOTIFICATION vvvv
$notifications = $db->query('SELECT * FROM notifications WHERE receiver_id = :user ORDER BY notif_time DESC', [
    ':user'=>$currentUser
])->findAll();

foreach($notifications as &$notification) {
    $sender_name = $db->query('SELECT l_name, f_name from accounts where school_id = :id', [
        ':id' => $notification['sender_id'] 
    ])->find();

    $room_name = $db->query('SELECT room_name from rooms where room_id = :room_id',[
        'room_id' => $notification['room_id']
    ])->find();

    $notification['sender_name'] = "{$sender_name['f_name']} {$sender_name['l_name']}";
    $notification['room_name'] = $room_name['room_name'];
}
// ^^^^ NAVBAR NOTIFICATION ^^^^

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if(isset($_POST['grouped'])) {
        $jsonGroup = $_POST['grouped'];
        // string json
        $decodedGroup = json_decode($jsonGroup, true);
        $encoded = json_encode($decodedGroup);

    
        unset($_POST['grouped']);
        view('group/group-results.view.php', [
            'heading' => 'Group Results',
            'encoded' =>    $encoded,
            'decodedGroup' => $decodedGroup,
            'room_id' => $_POST['room_id'],
            'notifications' => $notifications
        ]);
        
    } elseif (isset($_POST['_method'])) {
        $action = $_POST['_method'];
        unset($_POST['_method']);
        
        if ($action === 'PATCH') {
            if (isset($_POST['group_num'])) { 
                $groupNum = $_POST['group_num'];
                $memberNum = $_POST['member_num'];
                $room_id = $_POST['room_id'];
                
        
                $decodedGroup = json_decode($_POST['encodedGroup'], true);
                $encodedGroup = json_encode($decodedGroup);

                $decodedRemoved = json_decode($_POST['encodedRemoved'], true);
                $encodedRemoved = json_encode($decodedRemoved);

                $targetGroupNum = $_POST['move-to']; 

                $member = $decodedGroup[$groupNum][$memberNum];
                $canMove = true;

        
                    // Check if target group has a member with the same role
                    foreach ($decodedGroup[$targetGroupNum] as $mem) {
                        if ($mem[2] === $member[2]) {
                            $canMove = false;
                            break;
                        }
                    }
                
                    if ($canMove) {
                        // Remove from current group
                        array_splice($decodedGroup[$groupNum], $memberNum, 1);
                        // Add to target group
                        $decodedGroup[$targetGroupNum][] = $member;
                        $encodedGroup = json_encode($decodedGroup);
                        $decodedGroup = json_decode($encodedGroup, true);

                        
                        // vvvv NAVBAR NOTIFICATION vvvv
                        $notifications = $db->query('SELECT * FROM notifications WHERE receiver_id = :user ORDER BY notif_time DESC', [
                            ':user'=>$currentUser
                        ])->findAll();

                        foreach($notifications as &$notification) {
                            $sender_name = $db->query('SELECT l_name, f_name from accounts where school_id = :id', [
                                ':id' => $notification['sender_id'] 
                            ])->find();

                            $room_name = $db->query('SELECT room_name from rooms where room_id = :room_id',[
                                'room_id' => $notification['room_id']
                            ])->find();

                            $notification['sender_name'] = "{$sender_name['f_name']} {$sender_name['l_name']}";
                            $notification['room_name'] = $room_name['room_name'];
                        }
                        // ^^^^ NAVBAR NOTIFICATION ^^^^

                        view('group/group-results.view.php', [
                            'heading' => 'Group Results',
                            'encoded' =>    $encodedGroup,
                            'decodedGroup' => $decodedGroup,
                            'decodedRemoved' => $decodedRemoved,
                            'encodedRemoved' => $encodedRemoved,
                            'room_id' => $_POST['room_id'],
                            'notifications' => $notifications
                        ]);
                    } else {
                        view('group/group-results.view.php', [
                            'heading' => 'Group Results',
                            'encoded' =>    $encodedGroup,
                            'decodedGroup' => $decodedGroup,
                            'decodedRemoved' => $decodedRemoved,
                            'encodedRemoved' => $encodedRemoved,
                            'room_id' => $_POST['room_id'],
                            'notifications' => $notifications,
                            'errors'=> [
                                "cantmove-{$groupNum}-{$memberNum}" => "That group already has a member with the same role."
                            ]
                        ]);
                    }
            } else {
                $memberNum = $_POST['member_num'];
                $room_id = $_POST['room_id'];
                
        
                $decodedGroup = json_decode($_POST['encodedGroup'], true);
                $encodedGroup = json_encode($decodedGroup);

                $decodedRemoved = json_decode($_POST['encodedRemoved'], true);
                $encodedRemoved = json_encode($decodedRemoved);

                $targetGroupNum = $_POST['move-to']; 

                $member = $decodedRemoved[$memberNum];
                $canMove = true;

        
                    // Check if target group has a member with the same role
                    foreach ($decodedGroup[$targetGroupNum] as $mem) {
                        if ($mem[2] === $member[2]) {
                            $canMove = false;
                            break;
                        }
                    }
                
                    if ($canMove) {
                        // Remove from current group
                        array_splice($decodedRemoved, $memberNum, 1);
                        // Add to target group
                        $decodedGroup[$targetGroupNum][] = $member;
                        $encodedGroup = json_encode($decodedGroup);
                        $decodedGroup = json_decode($encodedGroup, true);

                        $encodedRemoved = json_encode($decodedRemoved);
                        $decodedRemoved = json_decode($encodedRemoved, true);

                        view('group/group-results.view.php', [
                            'heading' => 'Group Results',
                            'encoded' =>    $encodedGroup,
                            'decodedGroup' => $decodedGroup,
                            'room_id' => $_POST['room_id'],
                            'decodedRemoved' => $decodedRemoved,
                            'encodedRemoved' => $encodedRemoved,
                            'notifications' => $notifications,
                            'errors'=> [
                                "cantmove-{$memberNum}" => "That group already has a member with the same role."
                            ]
                        ]);
                    } else {
                        view('group/group-results.view.php', [
                            'heading' => 'Group Results',
                            'encoded' =>    $encodedGroup,
                            'decodedGroup' => $decodedGroup,
                            'room_id' => $_POST['room_id'],
                            'decodedRemoved' => $decodedRemoved,
                            'encodedRemoved' => $encodedRemoved,
                            'notifications' => $notifications,
                            'errors'=> [
                                "cantmove-{$memberNum}" => "That group already has a member with the same role."
                            ]
                        ]);
                    }
            }
    
        } elseif ($action === "DELETE") {
            $groupNum = $_POST['group_num'];
            $memberNum = $_POST['member_num'];
            $removed = $_POST['encodedRemoved'];
            $decodedRemoved = json_decode($removed, true);

            $decodedGroup = json_decode($_POST['encodedGroup'], true);
            $encodedGroup = json_encode($decodedGroup);


            $member = $decodedGroup[$groupNum][$memberNum];
            
            array_splice($decodedGroup[$groupNum], $memberNum, 1);
            $decodedRemoved[] = $member;


            $encodedGroup = json_encode($decodedGroup);
            $decodedGroup = json_decode($encodedGroup, true);
            $encodedRemoved = json_encode($decodedRemoved);
            $decodedRemoved = json_decode($encodedRemoved, true);

            view('group/group-results.view.php', [
                'heading' => 'Group Results',
                'encoded' =>    $encodedGroup,
                'decodedGroup' => $decodedGroup,
                'room_id' => $_POST['room_id'],
                'decodedRemoved' => $decodedRemoved,
                'encodedRemoved' => $encodedRemoved,
                'notifications' => $notifications,
                'errors'=> [
                    "cantmove-{$groupNum}-{$memberNum}" => "That group already has a member with the same role."
                ]
            ]);
        }



    } elseif (isset($_POST['finalize'])) {
        if(isset($_POST['encodedGroup'])) {
            $room_id = $_POST['room_id'];
            $encodedGroup = $_POST['encodedGroup'];
            $decodedGroup = json_decode($encodedGroup, true);
        
            if(isset($_POST['encodedRemoved'])) {
                // THERE'S STILL STUDENTS WHO HAVE NO GROUP
                $encodedRemoved = $_POST['encodedRemoved'];
                $decodedRemoved = json_decode($encodedRemoved, true);
        
                view('group/group-results.view.php', [
                    'heading' => 'Group Results',
                    'encoded' =>    $encodedGroup,
                    'decodedGroup' => $decodedGroup,
                    'room_id' => $_POST['room_id'],
                    'decodedRemoved' => $decodedRemoved,
                    'encodedRemoved' => $encodedRemoved,
                    'notifications' => $notifications,
                    'errors'=> [
                        "removednotempty" => "All students must be assigned to a group."
                    ]
                ]);
                
            } else {
                $roomHasGroup = $db->query('select * from room_groups where room_id = :room_id', [
                    ':room_id' => $room_id
                ])->find();
        
                if (! $roomHasGroup) {
                    $db->query('INSERT INTO room_groups(room_id, groups_json) VALUES(:room_id, :jsongroups)', [
                        ':room_id' => $room_id,
                        ':jsongroups' => $encodedGroup
                    ]);

                    // NOTIFICATION TO ALL STUDENT in the room:
                    $roomAllStudents = $db->query('SELECT * from room_list where room_id = :room_id', [
                        ':room_id' => $room_id
                    ])->findAll();

                    foreach($roomAllStudents as $student) {
                        $db->query('INSERT INTO notifications(sender_id, receiver_id, room_id, notif_type) VALUES (:prof, :student, :room, :type)', [
                            ':prof'=>$currentUser,
                            ':student'=>$student['school_id'],
                            ':room'=>$student['room_id'],
                            ':type'=>'group_create'
                        ]);
                    }



                    header("Location: /room?room_id={$room_id}");
                    exit();
        
                } else {
                    $db->query('update room_groups set groups_json = :jsongroups where room_id = :room_id', [
                        ':jsongroups' => $encodedGroup,
                        ':room_id' => $room_id
                    ]);

                    $roomAllStudents = $db->query('SELECT * from room_list where room_id = :room_id', [
                        ':room_id' => $room_id
                    ])->findAll();

                    foreach($roomAllStudents as $student) {
                        $db->query('INSERT INTO notifications(sender_id, receiver_id, room_id, notif_type) VALUES (:prof, :student, :room, :type)', [
                            ':prof'=>$currentUser,
                            ':student'=>$student['school_id'],
                            ':room'=>$student['room_id'],
                            ':type'=>'group_modify'
                        ]);


                    }
        
                    
                    header("Location: /room?room_id={$room_id}");
                    exit();
                }
            }
        
        }
        
    } else {
        header('location: /dashboard');
        exit();
    }
} else {
    header('location: /dashboard');
    exit();
}

