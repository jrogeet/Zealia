<?php

view('rooms/create.view.php', [
    'heading' => 'Create Room',
    'errors' => []
]);

