<?php

view("account/test.view.php", [
    'heading' =>'Personality Test',
]);