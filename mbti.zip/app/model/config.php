<?php

return [
    'database' => [
        'host' => 'localhost',
        'port' => 3306,
        'dbname' => 'mbti',
        'charset' => 'utf8mb4'
    ]
    // ,

    // 'services' => [
    //     'prerender' => [
    //         'token' =>'',
    //         'secret' => ''
    //     ]
    // ]
];