<?php

use Model\App;
use Model\Database;
use Core\Validator;

$db = App::resolve(Database::class);

if (isset($_POST['id_change'])) {
    $db->query('UPDATE accounts SET school_id = :new_id  WHERE school_id = :school_id',[
        ':new_id' => $_POST['id_change'],
        ':school_id' => $_POST['school_id']
    ]);

    header('Location: /admin');
    exit();

} elseif (isset($_POST['l_name'])) {
    $db->query('UPDATE accounts SET l_name = :l_name  WHERE school_id = :school_id',[
        ':l_name' => $_POST['l_name'],
        ':school_id' => $_POST['school_id']
    ]);

    header('Location: /admin');
    exit();
} elseif (isset($_POST['f_name'])) {
    $db->query('UPDATE accounts SET f_name = :f_name  WHERE school_id = :school_id',[
        ':f_name' => $_POST['f_name'],
        ':school_id' => $_POST['school_id']
    ]);

    header('Location: /admin');
    exit();
}elseif (isset($_POST['personality_type'])) {

    if ($_POST['personality_type'] == "null") {
        $db->query('UPDATE accounts SET personality_type = NULL  WHERE school_id = :school_id',[
            ':school_id' => $_POST['school_id']
        ]);
    }
 
    $db->query('UPDATE accounts SET personality_type = :personality_type  WHERE school_id = :school_id',[
        ':personality_type' => $_POST['personality_type'],
        ':school_id' => $_POST['school_id']
    ]);

    header('Location: /admin');
    exit();
} elseif (isset($_POST['email'])) {
    $db->query('UPDATE accounts SET email = :email  WHERE school_id = :school_id',[
        'email' => $_POST['email'],
        ':school_id' => $_POST['school_id']
    ]);  

    header('Location: /admin');
    exit();
}