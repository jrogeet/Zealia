<?php

use Model\App;
use Model\Database;
use Core\Validator;

$school_id = $_POST["school_id"];
$email = $_POST["email"];
$fname = $_POST["fname"];
$lname = $_POST["lname"];
$password = $_POST["password"];
$confirm_password = $_POST["confirm_password"];



// validate form inputs
$errors = [];

if (! Validator::email($email)) {
    $errors['email'] = 'Please provide a valid email address.';
}

if (! Validator::string($password, 7, 255)) {
    $errors['password'] = 'Please provide a password with a minimum length of 7 characters.';
} elseif ($password !== $confirm_password) {
    $errors['password'] = 'Please confirm if the password match!';
}

if ( ! preg_match("/[a-z]/i", $password)) {
    $errors['password-letter'] = 'Password must contain at least one letter';
}

if (! preg_match("/[0-9]/", $password)) {
    $errors['password-number'] = 'Password must contain at least one number';
}

if (! Validator::string($fname, 1, 255) || ! Validator::string($lname,1, 255)) {
    $errors['names'] = 'You must provide a First name and a Surname';
}

if(! empty($errors)) {
    return view('auth/registration/create.view.php', [
        'errors' => $errors,
        'heading' => 'Register'
    ]);
}

$db = App::resolve(Database::class);
// check if account already exists
$user = $db->query('select * from accounts where school_id = :school_id or email = :email', [
    ':school_id' => $school_id,
    ':email'=> $email,
])->find();


if ($user) {
    // if school_id and email already has an account
    // redirect to login page
    // header('location: /login');
    // exit();

    $errors['regexist'] = 'School ID or Email already used in an account. <br>Please try to login';

    return view('auth/login/create.view.php', [
        'errors' => $errors,
    ]);
} else {
    // if not, save into the database
    
    $activation_token = bin2hex(random_bytes(16));

    $activation_token_hash = hash("sha256", $activation_token);

    $email_parts = explode('@', $email);

    $domain = array_pop($email_parts);
    if ($domain === 'student.fatima.edu.ph') {
        $usertype = 'student';
    } elseif ($domain === 'fatima.edu.ph') {
        $usertype = 'professor';
    }

    $db->query("INSERT INTO accounts(school_id, email, password, l_name, f_name, account_type, account_activation_hash)
    VALUES(:school_id, :email, :password, :l_name, :f_name, :account_type, :activation_token_hash)", [
        ':school_id'=> $school_id,
        ':email'=> $email,
        ':password' => password_hash($password, PASSWORD_BCRYPT),
        ':l_name'=> $lname,
        ':f_name'=> $fname,
        ':account_type'=> $usertype,
        ':activation_token_hash' => $activation_token_hash
    ]);

    $mail = require base_path('app/model/mailer.php');

    $mail->setFrom('ambitionxmbti@gmail.com', 'NoReply@aMBiTIon');
    $mail->addAddress($email);
    $mail->Subject="Account Activation";
    $mail->Body = <<< END
    
        Click <a href="mbti.test/active-success?token=$activation_token">here</a>
        to activate your account.
    END;

    try {
        $mail->send();
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer error: {$mail->ErrorInfo}";
        exit;
    }


    // then, redirect to login page
    // view("auth/login/create.view.php", [
    //     "loginmessage" => "Account created successfully!"
    // ]);

    header("Location: /activate-account");
    exit();
}
