<?php

use Model\App;
use Model\Database;
use Core\Validator;

$db = App::resolve(Database::class);

// Sanitize input
$school_id = $_POST['school_id'];
$password = $_POST['password'];

$errors = [];

// Validate input
if (!Validator::string($school_id) || strlen($school_id) < 5) { // Example: school_id should be at least 5 characters
    $errors['school_id'] = 'Please provide a valid school id number.';
}

if (!Validator::string($password) || strlen($password) < 8) { // Example: password should be at least 8 characters
    $errors['password'] = 'Please provide a valid password.';
}

if (!empty($errors)) {
    return view('auth/login/create.view.php', [
        'errors' => $errors
    ]);
}

// Using parameterized queries to prevent SQL injection
$user = $db->query('SELECT * FROM accounts WHERE school_id = :school_id', [
    ':school_id' => $school_id
])->find();

if (!$user) {
    return view('auth/login/create.view.php', [
        'errors' => [
            'school_id' => "Invalid login credentials."
        ],
        'heading' => "Login"
    ]);
}

if (password_verify($password, $user['password'])) {
    if ($user["account_activation_hash"] === NULL) {
        login($user); // Assuming login() handles session securely

        if ($_SESSION['user']['account_type'] === 'admin') {
            header('Location: /admin');
            exit();
        }

        header('Location: /dashboard');
        exit();
    }

    return view('auth/login/create.view.php', [
        'errors' => [
            'activate' => "Please activate your Email before logging in!"
        ]
    ]);
}

return view('auth/login/create.view.php', [
    'errors' => [
        'school_id' => "Invalid login credentials."
    ],
    'heading' => "Login"
]);

