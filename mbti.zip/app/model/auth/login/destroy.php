<?php


logout();

header('location: /');
exit();