<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personality Test</title>
    <link rel="stylesheet" type="text/css" href="assets/css/partials/navbar.css">
    <link rel="stylesheet" type="text/css" href="assets/css/partials/footer.css">
    <link rel="stylesheet" type="text/css"  href="/assets/css/account/perso-test.css">
</head>

<style>
    <?php include base_path('public/assets/css/shared-styles.css'); ?>
</style>

<body>
    <?php  //view('partials/nav.view.php', ['notifications' => $notifications])?>

    <div class="intro" id="introDiv">
        <h1 class="page-heading"><?= $heading ?></h1>
        <button  class="start" id="startButton">Start Test</button>
    </div>
    
    <main id="main">
        
    </main>

    <div class="test-container" id="testContainer">
        <div class="choices" id="choicesDiv">
            <button class="checkboxes" id="SD">Strongly Disagree</button>
            <button class="checkboxes" id="D">Disagree</button>
            <button class="checkboxes" id="SLD">Slighty Disagree</button>
            <button class="checkboxes" id="N">Neutral</button>
            <button class="checkboxes" id="SLA">Slightly Agree</button>
            <button class="checkboxes" id="A">Agree</button>
            <button class="checkboxes" id="SA">Strongly Agree</button>
        </div>

        <div class="back" id="backDiv">
            <button class="prev" id="prevQ" onclick="PrevQ()">Back</button>
        </div>
    </div>

    

    <div class="result-page" id="resultPage">
        <div class="result-heading">
            <h1 class="result-heading-text" id="MBTI">INFJ</h1>
        </div>
            
        <div class="result-bar-container">
            <div class="result-bar" id="extroBar"> <!--EXTRO BAR-->
                <div class="fill" style="width: 75%;"></div>
            </div>

            <div class="percentage-label">  <!--EXTRO LABEL-->
                Extroversion: <span id="extroversion"></span> | Introversion: <span id="introversion"></span>
            </div>

            <div class="result-bar" id="intuiBar"> <!--INTUI BAR-->
                <div class="fill" style="width: 75%;"></div>
            </div>

            <div class="percentage-label">  <!--INTUI LABEL-->
                Intuition: <span id="intuition"></span> | Sensing: <span id="sensing"></span>
            </div>

            <div class="result-bar" id="feelBar"> <!--FEEL BAR-->
                <div class="fill" style="width: 75%;"></div>
            </div>

            <div class="percentage-label">  <!--FEEL LABEL-->
                Feeling: <span id="feeling"></span> | Thinking: <span id="thinking"></span>
            </div>

            <div class="result-bar" id="judgeBar"> <!-- JUDGE BAR-->
                <div class="fill" style="width: 75%;"></div>
            </div>

            <div class="percentage-label">  <!--JUDGE LABEL-->
                Judging: <span id="judging"></span> | Perceiving: <span id="perceiving">25%</span>
            </div>

        </div>
        
        <div>
            <button class="save-result" onclick="confirmResult()">Save Test Result</button>
        </div>
        
    </div>



    <!-- SEND TEST RESULT TO PHP: -->

    <form id="myForm" action="/test" method="post">
        <input type="hidden" name="jsonData" id="jsonData" value="">
    </form>
    
    <script src="../assets/js/questions.js"></script>

</body>
</html>