<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personality Test</title>
    <link rel="stylesheet" type="text/css" href="assets/css/partials/navbar.css">
    <link rel="stylesheet" type="text/css"  href="assets/css/account/account.css">
</head>

<style>
    <?php 
        
        include base_path('public/assets/css/shared-styles.css');

    ?>

</style>

<body>
    <?php //  view('partials/nav.view.php', ['notifications' => $notifications]) ?>


    <div class="container">
        <h1>Profile</h1>
    </div>

</body>
</html>

