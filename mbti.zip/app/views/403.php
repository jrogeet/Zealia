<?php

echo '403 error';
echo '<br>';
echo 'You are unauthorized to view this page!';