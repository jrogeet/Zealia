<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AMBITION</title>


    <link rel="stylesheet" type="text/css" href="assets/css/partials/navbar.css">
    <link rel="stylesheet" type="text/css"  href="assets/css/mbti.css">
    <link rel="stylesheet" type="text/css"  href="assets/css/partials/footer.css">
</head>

<style>
    <?php 
        
        require base_path('public/assets/css/shared-styles.css');

    ?>

</style>
<body>
    <?php if(isset($notifications)){
        view('partials/nav.view.php', ['notifications' => $notifications]);
    } elseif (! isset($notifications)) {
        view('partials/nav.view.php');
    }
    ?>
    
    <main>
        <section class="section-hero-mbti">
            <div class="mbti-hero">
                <div class="mbti-hero-header">
                    <h1>Exploring Personality Types Through <span class="mbti-m mbti-mbti">M</span><span class="mbti-b mbti-mbti">B</span><span class="mbti-t mbti-mbti">T</span><span class="mbti-i mbti-mbti">I</span></h1>
                    <p>MBTI is a tool that identifies and classifies individuals into specific personality types by assessing their preferences in four dichotomies: Extraversion<span class="mbti-m">/</span>Introversion, Sensing<span class="mbti-b">/</span>iNtuition, Thinking<span class="mbti-t">/</span>Feeling, and Judging<span class="mbti-m">/</span>Perceiving. It offers a framework for understanding behaviors, communication styles, and decision-making processes.</p>
                </div>

                <div class="mbti-hero-test">
 
                    <a class="mbti-test-btn" href="/test" target="_blank">Take Test</a>

                    <span class="mbti-test-support test-support1">Curious about your personality type?</span>
                    <span class="mbti-test-support">Discover it now by simply clicking the button above!</span>
                </div>
            </div>
        </section>

        <section class="section-cards-mbti">
            <div class="deck-container">
                <h2 class="deck-header">Personality Types</h2>
                
                <div class="deck">
                    <div class="cards card-purple">
                        <img src="assets/images/mbti-avatars/png/INTJ.png" class="mbti-abimg mbti-intj-img">
                        <div class="card-content">

                            <span class="card-header">I<span class="cards-mbti-i">NT</span>J</span>
                            <span class="card-header-acronym">I-Introverted, N-Intuitive, T-Thinking, J-Judging</span>
                            <p class="card-description">Strategic and independent thinkers, driven by innovation, known for their vision and problem-solving abilities.</p>
                        </div>
                    </div>

                    <div class="cards card-purple">
                        <img src="assets/images/mbti-avatars/png/INTP.png" class="mbti-abimg mbti-intp-img">
                        <div class="card-content">

                            <span class="card-header">I<span class="cards-mbti-i">NT</span>P</span>
                            <span class="card-header-acronym">I-Introverted, N-Intuitive, T-Thinking, P-Perceiving</span>
                            <p class="card-description">Innovative and curious, seeks understanding and knowledge, excels in abstract thinking.</p>
                        </div>     
                    </div>

                    <div class="cards card-purple">
                        <img src="assets/images/mbti-avatars/png/ENTJ.png" class="mbti-abimg mbti-entj-img">
                        <div class="card-content">

                            <span class="card-header">E<span class="cards-mbti-i">NT</span>J</span>
                            <span class="card-header-acronym">E-Extroverted, N-Intuitive, T-Thinking, J-Judging</span>
                            <p class="card-description">Confident and decisive leaders, strong-willed and strategic, focused on long-term goals and efficient systems.</p>
                        </div>
                    </div>

                    <div class="cards card-purple"> 
                        <img src="assets/images/mbti-avatars/png/ENTP.png" class="mbti-abimg mbti-entp-img">
                        <div class="card-content ">

                            <span class="card-header">E<span class="cards-mbti-i">NT</span>P</span>
                            <span class="card-header-acronym">E-Extroverted, N-Intuitive, T-Thinking, P-Perceiving</span>
                            <p class="card-description">Resourceful and intellectually quick, enjoys debating ideas, driven by a desire to explore new concepts.</p>
                    </div>
                    </div>

                    <div class="cards card-green">
                        <img src="assets/images/mbti-avatars/png/INFJ.png" class="mbti-abimg mbti-infj-img">
                        <div class="card-content">

                            <span class="card-header">I<span class="cards-mbti-m">NF</span>J</span>
                            <span class="card-header-acronym">I-Introverted, N-Intuitive, F-Feeling, J-Judging</span>
                            <p class="card-description">Insightful and compassionate, often creative and idealistic, driven by deep values and visions.</p>
                    </div>
                    </div>

                    <div class="cards card-green">
                        <img src="assets/images/mbti-avatars/png/INFP.png" class="mbti-abimg mbti-infp-img">
                        <div class="card-content">

                            <span class="card-header">I<span class="cards-mbti-m">NF</span>P</span>
                            <span class="card-header-acronym">I-Introverted, N-Intuitive, F-Feeling, P-Perceiving</span>
                            <p class="card-description">Imaginative and empathetic, guided by strong inner values and a quest for authenticity.</p>
                    </div>
                    </div>

                    <div class="cards card-green">
                        <img src="assets/images/mbti-avatars/png/ENFJ.png" class="mbti-abimg mbti-enfj-img">
                        <div class="card-content">

                            <span class="card-header">E<span class="cards-mbti-m">NF</span>J</span>
                            <span class="card-header-acronym">E-Extraverted, N-Intuitive, F-Feeling, J-Judging</span>
                            <p class="card-description">Charismatic and empathetic, inspires others toward a common goal, values harmony and cooperation.</p>
                    </div>
                    </div>

                    <div class="cards card-green">
                        <img src="assets/images/mbti-avatars/png/ENFP.png" class="mbti-abimg mbti-enfp-img">
                        <div class="card-content">

                            <span class="card-header">E<span class="cards-mbti-m">NF</span>P</span>
                            <span class="card-header-acronym">E-Extraverted, N-Intuitive, F-Feeling, P-Perceiving</span>
                            <p class="card-description">Enthusiastic and creative, sees possibilities everywhere, values personal growth and authenticity.</p>
                    </div>
                    </div>

                    <div class="cards card-blue">
                        <img src="assets/images/mbti-avatars/png/ISTJ.png" class="mbti-abimg mbti-istj-img">
                        <div class="card-content">

                            <span class="card-header">I<span class="cards-mbti-b">S</span>T<span class="cards-mbti-b">J</span></span>
                            <span class="card-header-acronym">I-Introverted, S-Sensing, T-Thinking, J-Judging</span>
                            <p class="card-description">Practical and responsible, values traditions, known for their reliability and logical thinking.</p>
                        </div>        
                    </div>

                    <div class="cards card-blue">
                        <img src="assets/images/mbti-avatars/png/ISFJ.png" class="mbti-abimg mbti-isfj-img">
                        <div class="card-content">

                            <span class="card-header">I<span class="cards-mbti-b">S</span>F<span class="cards-mbti-b">J</span></span>
                            <span class="card-header-acronym">I-Introverted, S-Sensing, F-Feeling, J-Judging</span>
                            <p class="card-description">Nurturing and dependable, dedicated to helping others, with a strong attention to detail.</p>
                        </div>
                    </div>

                    <div class="cards card-blue">
                        <img src="assets/images/mbti-avatars/png/ESTJ.png" class="mbti-abimg mbti-estj-img">
                        <div class="card-content">
                            <span class="card-header">E<span class="cards-mbti-b">S</span>T<span class="cards-mbti-b">J</span></span>
                            <span class="card-header-acronym">E-Extraverted, S-Sensing, T-Thinking, J-Judging</span>
                            <p class="card-description">Efficient and organized, natural leaders, decisive and practical in approach.</p>
                        </div>
                    </div>

                    <div class="cards card-blue">
                        <img src="assets/images/mbti-avatars/png/ESFJ.png" class="mbti-abimg mbti-esfj-img">
                        <div class="card-content">
                            <span class="card-header">E<span class="cards-mbti-b">S</span>F<span class="cards-mbti-b">J</span></span>
                            <span class="card-header-acronym">E-Extraverted, S-Sensing, F-Feeling, J-Judging</span>
                            <p class="card-description">Warm and people-oriented, enjoys caring for others, highly sociable and community-driven.</p>
                        </div>
                    </div>

                    <div class="cards card-gold">
                        <img src="assets/images/mbti-avatars/png/ISTP.png" class="mbti-abimg mbti-istp-img">
                        <div class="card-content">
                            <span class="card-header">I<span class="cards-mbti-t">S</span>T<span class="cards-mbti-t">P</span></span>
                            <span class="card-header-acronym">I-Introverted, S-Sensing, T-Thinking, P-Perceiving</span>
                            <p class="card-description">Analytical and adaptable, loves hands-on exploration, skilled at troubleshooting and mastering tools.</p>
                        </div>
                    </div>

                    <div class="cards card-gold">
                        <img src="assets/images/mbti-avatars/png/ISFP.png" class="mbti-abimg mbti-isfp-img">
                        <div class="card-content">
                            <span class="card-header">I<span class="cards-mbti-t">S</span>F<span class="cards-mbti-t">P</span></span>
                            <span class="card-header-acronym">I-Introverted, S-Sensing, F-Feeling, P-Perceiving</span>
                            <p class="card-description">Gentle and artistic, values harmony, creativity, and individual expression.</p>
                        </div>
                    </div>

                    <div class="cards card-gold">
                        <img src="assets/images/mbti-avatars/png/ESTP.png" class="mbti-abimg mbti-estp-img">
                        <div class="card-content">
                            <span class="card-header">E<span class="cards-mbti-t">S</span>T<span class="cards-mbti-t">P</span></span>
                            <span class="card-header-acronym">E-Extraverted, S-Sensing, T-Thinking, P-Perceiving</span>
                            <p class="card-description">Energetic and action-oriented, enjoys challenges, quick to find practical solutions.</p>
                        </div>
                    </div>

                    <div class="cards card-gold">
                        <img src="assets/images/mbti-avatars/png/ESFP.png" class="mbti-abimg mbti-esfp-img">
                        <div class="card-content">
                            <span class="card-header">E<span class="cards-mbti-t">S</span>F<span class="cards-mbti-t">P</span></span>
                            <span class="card-header-acronym">E-Extraverted, S-Sensing, F-Feeling, P-Perceiving</span>
                            <p class="card-description">Spontaneous and enthusiastic, loves being the center of attention, thrives on connecting with others.</p>
                        </div>
                    </div>

                </div>

            </div>
        </section>
    
    </main>        
    <?php view('partials/footer.php')?>

    <script src="assets/js/effects.js"></script>

</body>
</html>