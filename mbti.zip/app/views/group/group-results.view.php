<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <link rel="stylesheet" type="text/css" href="assets/css/partials/navbar.css">
    <link rel="stylesheet" type="text/css" href="assets/css/partials/footer.css">
    <link rel="stylesheet" type="text/css"  href="assets/css/rooms/groups/group-result.css">
</head>

<style>
    <?php include base_path('public/assets/css/shared-styles.css'); ?>
</style>

<body>
    <?php view('partials/nav.view.php', ['notifications' => $notifications])?>


    <main class="main-container">
        <?php if (isset($errors["removednotempty"])): ?>
                <p class="errormsg errormsg-removed-not-empty"><?= $errors["removednotempty"] ?></p>
        <?php endif; ?>

        <?php if(isset($decodedRemoved) && !empty($decodedRemoved)): ?>
            <div class="temp-removed-result-wrap">
                <div class="temp-removed-container">
                    <table class="temp-removed-table result-table">
                        <thead class="temp-removed-thead result-thead">
                            <tr class="temp-removed-headrow result-headrow">
                                <th class="temp-removed-headcell result-headcell" colspan="4">
                                    <span class="table-group-number no-group-header-text">No Groups:</span>
                                </th>
                                <th class="temp-removed-headcell result-headcell">
                                    <span class="table-group-number edit-option-header">Edit Options:</span>
                                </th>
                            </tr>
                        </thead>

                        <tbody class="temp-removed-tbody result-tbody">
                            
                                <?php foreach ($decodedRemoved as $remIndex => $member) {?>
                                    <?php 
                                         if ($member[2] === "Leader") {
                                            $role =  "leader";       
                                        } elseif ($member[2] === "Analyst") { 
                                            $role ="analyst";   
                                        } elseif ($member[2] === "Programmer") { 
                                            $role = "programmer";
                                        } elseif ($member[2] === "Designer") { 
                                            $role = "designer";
                                        }    
                                    ?>

                                    <tr class="temp-removed-row result-row">
                                    <?php if ($member[2] === "Leader") {?>
                                        <td class="result-imgcell">
                                        <?php if (! isset($errors["removednotempty"])): ?>
                                            <img class="lead-banner-star" src="assets/images/PixelArt/bannerstar.png" alt="Group Leader Icon">
                                        <?php elseif (isset($errors["removednotempty"])): ?>
                                            <img class="lead-banner-star" src="/assets/images/PixelArt/bannerstar.png" alt="Group Leader Icon"></td>
                                        <?php endif; ?>
                                        </td>
                                    <?php } else { ?>
                                        <td class="result-imgcell"></td>
                                    <?php } ?>
                                        <td class="leader-name-cell result-name-cell result-user-cells">
                                            <span class="leader-cell-text"><?= $member[0] ?></span>
                                        </td>
                                        <td class="leader-type-cell result-type-cell result-user-cells">
                                            <span class="leader-cell-text"><?= $member[1] ?></span>
                                        </td>
                                        <td class="<?= $role ?>-role-cell result-role-cell result-user-cells">
                                            <span class="<?= $role ?>-cell-text <?= $role ?>-cell-text-role"><?= $member[2] ?></span>
                                        </td>

                                    <!-- EDIT OPTIONS -->
                                    <td class="result-edit-cell">                
                                    <form action="/groups" method="post">
                                        <input type="hidden" name="_method" value="PATCH">
                                        <input type="hidden" name="member_num" value="<?= $remIndex ?>">

                                        <input type="hidden" name="encodedRemoved" value="<?= htmlspecialchars($encodedRemoved, ENT_QUOTES, 'UTF-8') ?>">
                                        <input type="hidden" name="encodedGroup" value="<?= htmlspecialchars($encoded, ENT_QUOTES, 'UTF-8') ?>">
                                        <input type="hidden" name="room_id" value="<?= $_POST['room_id'] ?>">


                                        <div class='move-to-container move-to-container-<?= $index ?>-<?= $memIndex ?>' id="move-to-container-<?= $remIndex ?>" style="display:none;">
                                                <button type="button" onclick="toggleEditOptions('re-move-btn-container-<?= $remIndex ?>', 'move-to-container-<?= $remIndex ?>')" class="back-btn">←</button>

                                                <div class="move-to-select-container">
                                                    <label for="move-to" class="move-to-label">Move to:</label>
                                                    <select class="move-to-select" name="move-to" id="move-to-<?= $remIndex ?>"  required>
                                                    <option value="" selected disabled>Select a group</option>
                                                        <?php foreach ($decodedGroup as $idx => $grp) { ?>
                                                            <option value="<?= $idx ?>" class="move-to-option">Group <?= $idx + 1 ?></option>
                                                        <?php } ?>
                                                    </select>

                                                    <button type="submit" class="move-btn">Confirm</button>
                                                </div>

                                            </div>

                                    </form>

                                

                                    <div class="re-move-btn-container re-move-btn-container-<?= $remIndex ?>" id="re-move-btn-container-<?= $remIndex ?>">
                                        <button onclick="toggleEditOptions('move-to-container-<?= $remIndex ?>', 're-move-btn-container-<?= $remIndex ?>')" class="move-btn">Move</button>
                                    </div>
                                    
                                    <?php if (isset($errors["cantmove-{$remIndex}"])): ?>
                                        <p class="errormsg"><?= $errors["cantmove-{$remIndex}"] ?></p>
                                    <?php endif; ?>
                                </td>


                                    </tr>
                                <?php } ?>
                            
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <div class="result-wrap">
            <div class="result-header-container">
                <h1 class="result-header" id="groups-result-header">GROUPS FORMED</h1>
                <div class="row-column-container">
                    <button class="result-sort result-column-sort" onclick="setFlexDirection('column')">
                        <img src="assets/images/PixelArt/column-purple-transparent.png" alt="Column Sort">
                    </button>
                    <button class="result-sort result-row-sort" onclick="setFlexDirection('row')">
                        <img src="assets/images/PixelArt/row-green-transparent.png" alt="Row Sort">
                    </button>
                </div>
            </div>
            <div class="table-result">
                <?php foreach ($decodedGroup as $index => $group) {?>
                <!-- OUTER TABLE -->
                <table class="result-table">
                    <thead class="result-thead">
                        <tr class="result-headrow">
                            <th class="result-headcell" colspan="4">
                                <span class="table-group-number">Group</span>
                                <?php 
                                    $curIndex = ($index + 1) % 4;
                                    switch ($curIndex) {
                                        case 1:
                                            $classnum =  "class1";
                                            break;
                                        case 2:
                                            $classnum =  "class2";
                                            break;
                                        case 3:
                                            $classnum =   "class3";
                                            break;
                                        default:
                                            $classnum =   "class4";
                                            break;
                                    }
                                ?>
                                <span class="table-group-number table-group-number-<?= $classnum ?>"><?= $index + 1?></span>
                            </th>
                            <th class="temp-removed-headcell result-headcell">
                                <span class="table-group-number edit-option-header">Edit Options:</span>
                            </th>
                        </tr>
                    </thead>
            <!-- OUTER T BODY -->
                    <tbody class="result-tbody">
                        <tr class="result-row result-leader-row">
                            <?php foreach ($group as $memIndex => $member) {?>
                                <?php if ($member[2] === "Leader") {?>
                                    <td class="result-imgcell">
                                    <?php if (! isset($errors["removednotempty"])): ?>
                                        <img class="lead-banner-star" src="assets/images/PixelArt/bannerstar.png" alt="Group Leader Icon">
                                    <?php elseif (isset($errors["removednotempty"])): ?>
                                        <img class="lead-banner-star" src="/assets/images/PixelArt/bannerstar.png" alt="Group Leader Icon"></td>
                                    <?php endif; ?>
                                    </td>
                                    <td class="leader-name-cell result-name-cell result-user-cells">
                                        <span class="leader-cell-text"><?= $member[0] ?></span>
                                    </td>
                                    <td class="leader-type-cell result-type-cell result-user-cells">
                                        <span class="leader-cell-text"><?= $member[1] ?></span>
                                    </td>
                                    <td class="leader-role-cell result-role-cell result-user-cells">
                                        <span class="leader-cell-text leader-cell-text-role"><?= $member[2] ?></span>
                                    </td>

                                <!-- EDIT OPTIONS -->
                                    <td class="result-edit-cell">                
                                        <form action="/groups" method="post">
                                            <input type="hidden" name="_method" value="PATCH">
                                            <input type="hidden" name="group_num" value="<?= $index ?>">
                                            <input type="hidden" name="member_num" value="<?= $memIndex ?>">
                                            <input type="hidden" name="encodedRemoved" value="<?= htmlspecialchars($encodedRemoved, ENT_QUOTES, 'UTF-8') ?>">

                                            <input type="hidden" name="encodedGroup" value="<?= htmlspecialchars($encoded, ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="room_id" value="<?= $_POST['room_id'] ?>">


                                            <div class='move-to-container move-to-container-<?= $index ?>-<?= $memIndex ?>' id="move-to-container-<?= $index ?>-<?= $memIndex ?>" style="display:none;">
                                                <button type="button" onclick="toggleEditOptions('re-move-btn-container-<?= $index ?>-<?= $memIndex ?>', 'move-to-container-<?= $index ?>-<?= $memIndex ?>')" class="back-btn">←</button>

                                                <div class="move-to-select-container">
                                                    <label for="move-to" class="move-to-label">Move to:</label>
                                                    <select class="move-to-select" name="move-to" id="move-to-<?= $index ?>-<?= $memIndex ?>"  required>
                                                    <option value="" selected disabled>Select a group</option>
                                                        <?php foreach ($decodedGroup as $idx => $grp) { ?>
                                                            <option value="<?= $idx ?>" class="move-to-option">Group <?= $idx + 1 ?></option>
                                                        <?php } ?>
                                                    </select>

                                                    <button type="submit" class="move-btn">Confirm</button>
                                                </div>

                                            </div>

                                        </form>

                                        <form action="/groups" method="post">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="group_num" value="<?= $index ?>">
                                            <input type="hidden" name="member_num" value="<?= $memIndex ?>">
                                            <input type="hidden" name="encodedGroup" value="<?= htmlspecialchars($encoded, ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="encodedRemoved" value="<?= htmlspecialchars($encodedRemoved, ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="room_id" value="<?= $_POST['room_id'] ?>">

                                            <div class="remove-btn-container remove-btn-container-<?= $index ?>-<?= $memIndex ?>" id="remove-btn-container-<?= $index ?>-<?= $memIndex ?>" style="display:none;">
                                                <button type="button" onclick="toggleEditOptions('re-move-btn-container-<?= $index ?>-<?= $memIndex ?>', 'remove-btn-container-<?= $index ?>-<?= $memIndex ?>')" class="back-btn">Back</button>
                                                <label for="remove" class="remove-label">Remove</label>
                                                <button type="submit" class="remove-btn">Confirm</button>
                                            </div>
                                        </form>
                                        

                                        <div class="re-move-btn-container re-move-btn-container-<?= $index ?>-<?= $memIndex ?>" id="re-move-btn-container-<?= $index ?>-<?= $memIndex ?>">
                                            <button onclick="toggleEditOptions('move-to-container-<?= $index ?>-<?= $memIndex ?>', 're-move-btn-container-<?= $index ?>-<?= $memIndex ?>')" class="move-btn">Move</button>
                                            <button onclick="toggleEditOptions('remove-btn-container-<?= $index ?>-<?= $memIndex ?>', 're-move-btn-container-<?= $index ?>-<?= $memIndex ?>')" class="remove-btn">Remove</button>
                                        </div>
                                        
                                        <?php if (isset($errors["cantmove-{$index}-{$memIndex}"])): ?>
                                            <p class="errormsg"><?= $errors["cantmove-{$index}-{$memIndex}"] ?></p>
                                        <?php endif; ?>
                                    </td>


                                <?php } ?>
                            <?php } ?>
                        </tr>

                        <tr class="result-row result-analyst-row">
                            <?php foreach ($group as $memIndex => $member) {?>
                                <?php if ($member[2] === "Analyst") {?>
                                    <td class="result-imgcell"></td>
                                    <td class="analyst-name-cell result-name-cell result-user-cells">
                                        <span class="analyst-cell-text"><?= $member[0] ?></span>
                                    </td>
                                    <td class="analyst-type-cell result-type-cell result-user-cells">
                                        <span class="analyst-cell-text"><?= $member[1] ?></span>
                                    </td>
                                    <td class="analyst-role-cell result-role-cell result-user-cells">
                                        <span class="analyst-cell-text analyst-cell-text-role"><?= $member[2] ?></span>
                                    </td>
                                    <!-- EDIT OPTIONS -->
                                    <td class="result-edit-cell">                
                                        <form action="/groups" method="post">
                                            <input type="hidden" name="_method" value="PATCH">
                                            <input type="hidden" name="group_num" value="<?= $index ?>">
                                            <input type="hidden" name="member_num" value="<?= $memIndex ?>">
                                            <input type="hidden" name="encodedRemoved" value="<?= htmlspecialchars($encodedRemoved, ENT_QUOTES, 'UTF-8') ?>">

                                            <input type="hidden" name="encodedGroup" value="<?= htmlspecialchars($encoded, ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="room_id" value="<?= $_POST['room_id'] ?>">


                                            <div class='move-to-container move-to-container-<?= $index ?>-<?= $memIndex ?>' id="move-to-container-<?= $index ?>-<?= $memIndex ?>" style="display:none;">
                                                <button type="button" onclick="toggleEditOptions('re-move-btn-container-<?= $index ?>-<?= $memIndex ?>', 'move-to-container-<?= $index ?>-<?= $memIndex ?>')" class="back-btn">←</button>

                                                <div class="move-to-select-container">
                                                    <label for="move-to" class="move-to-label">Move to:</label>
                                                    <select class="move-to-select" name="move-to" id="move-to-<?= $index ?>-<?= $memIndex ?>"  required>
                                                    <option value="" selected disabled>Select a group</option>
                                                        <?php foreach ($decodedGroup as $idx => $grp) { ?>
                                                            <option value="<?= $idx ?>" class="move-to-option">Group <?= $idx + 1 ?></option>
                                                        <?php } ?>
                                                    </select>

                                                    <button type="submit" class="move-btn">Confirm</button>
                                                </div>

                                            </div>

                                        </form>

                                        <form action="/groups" method="post">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="group_num" value="<?= $index ?>">
                                            <input type="hidden" name="member_num" value="<?= $memIndex ?>">
                                            <input type="hidden" name="encodedGroup" value="<?= htmlspecialchars($encoded, ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="encodedRemoved" value="<?= htmlspecialchars($encodedRemoved, ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="room_id" value="<?= $_POST['room_id'] ?>">

                                            <div class="remove-btn-container remove-btn-container-<?= $index ?>-<?= $memIndex ?>" id="remove-btn-container-<?= $index ?>-<?= $memIndex ?>" style="display:none;">
                                                <button type="button" onclick="toggleEditOptions('re-move-btn-container-<?= $index ?>-<?= $memIndex ?>', 'remove-btn-container-<?= $index ?>-<?= $memIndex ?>')" class="back-btn">Back</button>
                                                <label for="remove" class="remove-label">Remove</label>
                                                <button type="submit" class="remove-btn">Confirm</button>
                                            </div>
                                        </form>
                                        

                                        <div class="re-move-btn-container re-move-btn-container-<?= $index ?>-<?= $memIndex ?>" id="re-move-btn-container-<?= $index ?>-<?= $memIndex ?>">
                                            <button onclick="toggleEditOptions('move-to-container-<?= $index ?>-<?= $memIndex ?>', 're-move-btn-container-<?= $index ?>-<?= $memIndex ?>')" class="move-btn">Move</button>
                                            <button onclick="toggleEditOptions('remove-btn-container-<?= $index ?>-<?= $memIndex ?>', 're-move-btn-container-<?= $index ?>-<?= $memIndex ?>')" class="remove-btn">Remove</button>
                                        </div>
                                        
                                        <?php if (isset($errors["cantmove-{$index}-{$memIndex}"])): ?>
                                            <p class="errormsg"><?= $errors["cantmove-{$index}-{$memIndex}"] ?></p>
                                        <?php endif; ?>
                                    </td>
                                <?php } ?>
                            <?php } ?>
                        </tr>

                        <tr class="result-row result-programmer-row">
                            <?php foreach ($group as $memIndex => $member) {?>
                                <?php if ($member[2] === "Programmer") {?>
                                    <td class="result-imgcell"></td>
                                    <td class="programmer-name-cell result-name-cell result-user-cells">
                                        <span class="programmer-cell-text"><?= $member[0] ?></span>
                                    </td>
                                    <td class="programmer-type-cell result-type-cell result-user-cells">
                                        <span class="programmer-cell-text"><?= $member[1] ?></span>
                                    </td>
                                    <td class="programmer-role-cell result-role-cell result-user-cells">
                                        <span class="programmer-cell-text programmer-cell-text-role"><?= $member[2] ?></span>
                                    </td>
                                    <!-- EDIT OPTIONS -->
                                    <td class="result-edit-cell">                
                                        <form action="/groups" method="post">
                                            <input type="hidden" name="_method" value="PATCH">
                                            <input type="hidden" name="group_num" value="<?= $index ?>">
                                            <input type="hidden" name="member_num" value="<?= $memIndex ?>">
                                            <input type="hidden" name="encodedRemoved" value="<?= htmlspecialchars($encodedRemoved, ENT_QUOTES, 'UTF-8') ?>">

                                            <input type="hidden" name="encodedGroup" value="<?= htmlspecialchars($encoded, ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="room_id" value="<?= $_POST['room_id'] ?>">


                                            <div class='move-to-container move-to-container-<?= $index ?>-<?= $memIndex ?>' id="move-to-container-<?= $index ?>-<?= $memIndex ?>" style="display:none;">
                                                <button type="button" onclick="toggleEditOptions('re-move-btn-container-<?= $index ?>-<?= $memIndex ?>', 'move-to-container-<?= $index ?>-<?= $memIndex ?>')" class="back-btn">←</button>

                                                <div class="move-to-select-container">
                                                    <label for="move-to" class="move-to-label">Move to:</label>
                                                    <select class="move-to-select" name="move-to" id="move-to-<?= $index ?>-<?= $memIndex ?>"  required>
                                                    <option value="" selected disabled>Select a group</option>
                                                        <?php foreach ($decodedGroup as $idx => $grp) { ?>
                                                            <option value="<?= $idx ?>" class="move-to-option">Group <?= $idx + 1 ?></option>
                                                        <?php } ?>
                                                    </select>

                                                    <button type="submit" class="move-btn">Confirm</button>
                                                </div>

                                            </div>

                                        </form>

                                        <form action="/groups" method="post">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="group_num" value="<?= $index ?>">
                                            <input type="hidden" name="member_num" value="<?= $memIndex ?>">
                                            <input type="hidden" name="encodedGroup" value="<?= htmlspecialchars($encoded, ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="encodedRemoved" value="<?= htmlspecialchars($encodedRemoved, ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="room_id" value="<?= $_POST['room_id'] ?>">

                                            <div class="remove-btn-container remove-btn-container-<?= $index ?>-<?= $memIndex ?>" id="remove-btn-container-<?= $index ?>-<?= $memIndex ?>" style="display:none;">
                                                <button type="button" onclick="toggleEditOptions('re-move-btn-container-<?= $index ?>-<?= $memIndex ?>', 'remove-btn-container-<?= $index ?>-<?= $memIndex ?>')" class="back-btn">Back</button>
                                                <label for="remove" class="remove-label">Remove</label>
                                                <button type="submit" class="remove-btn">Confirm</button>
                                            </div>
                                        </form>
                                        

                                        <div class="re-move-btn-container re-move-btn-container-<?= $index ?>-<?= $memIndex ?>" id="re-move-btn-container-<?= $index ?>-<?= $memIndex ?>">
                                            <button onclick="toggleEditOptions('move-to-container-<?= $index ?>-<?= $memIndex ?>', 're-move-btn-container-<?= $index ?>-<?= $memIndex ?>')" class="move-btn">Move</button>
                                            <button onclick="toggleEditOptions('remove-btn-container-<?= $index ?>-<?= $memIndex ?>', 're-move-btn-container-<?= $index ?>-<?= $memIndex ?>')" class="remove-btn">Remove</button>
                                        </div>
                                        
                                        <?php if (isset($errors["cantmove-{$index}-{$memIndex}"])): ?>
                                            <p class="errormsg"><?= $errors["cantmove-{$index}-{$memIndex}"] ?></p>
                                        <?php endif; ?>
                                    </td>
                                <?php } ?>
                            <?php } ?>
                        </tr>

                        <tr class="result-row result-designer-row">
                            <?php foreach ($group as $memIndex => $member) {?>
                                <?php if ($member[2] === "Designer") {?>
                                    <td class="result-imgcell"></td>
                                    <td class="designer-name-cell result-name-cell result-user-cells">
                                        <span class="designer-cell-text"><?= $member[0] ?></span>
                                    </td>
                                    <td class="designer-type-cell result-type-cell result-user-cells">
                                        <span class="designer-cell-text"><?= $member[1] ?></span>
                                    </td>
                                    <td class="designer-role-cell result-role-cell result-user-cells">
                                        <span class="designer-cell-text designer-cell-text-role"><?= $member[2] ?></span>
                                    </td>
                                    <!-- EDIT OPTIONS -->
                                    <td class="result-edit-cell">                
                                        <form action="/groups" method="post">
                                            <input type="hidden" name="_method" value="PATCH">
                                            <input type="hidden" name="group_num" value="<?= $index ?>">
                                            <input type="hidden" name="member_num" value="<?= $memIndex ?>">
                                            <input type="hidden" name="encodedRemoved" value="<?= htmlspecialchars($encodedRemoved, ENT_QUOTES, 'UTF-8') ?>">

                                            <input type="hidden" name="encodedGroup" value="<?= htmlspecialchars($encoded, ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="room_id" value="<?= $_POST['room_id'] ?>">


                                            <div class='move-to-container move-to-container-<?= $index ?>-<?= $memIndex ?>' id="move-to-container-<?= $index ?>-<?= $memIndex ?>" style="display:none;">
                                                <button type="button" onclick="toggleEditOptions('re-move-btn-container-<?= $index ?>-<?= $memIndex ?>', 'move-to-container-<?= $index ?>-<?= $memIndex ?>')" class="back-btn">←</button>

                                                <div class="move-to-select-container">
                                                    <label for="move-to" class="move-to-label">Move to:</label>
                                                    <select class="move-to-select" name="move-to" id="move-to-<?= $index ?>-<?= $memIndex ?>"  required>
                                                    <option value="" selected disabled>Select a group</option>
                                                        <?php foreach ($decodedGroup as $idx => $grp) { ?>
                                                            <option value="<?= $idx ?>" class="move-to-option">Group <?= $idx + 1 ?></option>
                                                        <?php } ?>
                                                    </select>

                                                    <button type="submit" class="move-btn">Confirm</button>
                                                </div>

                                            </div>

                                        </form>

                                        <form action="/groups" method="post">
                                            <input type="hidden" name="_method" value="DELETE">
                                            <input type="hidden" name="group_num" value="<?= $index ?>">
                                            <input type="hidden" name="member_num" value="<?= $memIndex ?>">
                                            <input type="hidden" name="encodedGroup" value="<?= htmlspecialchars($encoded, ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="encodedRemoved" value="<?= htmlspecialchars($encodedRemoved, ENT_QUOTES, 'UTF-8') ?>">
                                            <input type="hidden" name="room_id" value="<?= $_POST['room_id'] ?>">

                                            <div class="remove-btn-container remove-btn-container-<?= $index ?>-<?= $memIndex ?>" id="remove-btn-container-<?= $index ?>-<?= $memIndex ?>" style="display:none;">
                                                <button type="button" onclick="toggleEditOptions('re-move-btn-container-<?= $index ?>-<?= $memIndex ?>', 'remove-btn-container-<?= $index ?>-<?= $memIndex ?>')" class="back-btn">Back</button>
                                                <label for="remove" class="remove-label">Remove</label>
                                                <button type="submit" class="remove-btn">Confirm</button>
                                            </div>
                                        </form>
                                        

                                        <div class="re-move-btn-container re-move-btn-container-<?= $index ?>-<?= $memIndex ?>" id="re-move-btn-container-<?= $index ?>-<?= $memIndex ?>">
                                            <button onclick="toggleEditOptions('move-to-container-<?= $index ?>-<?= $memIndex ?>', 're-move-btn-container-<?= $index ?>-<?= $memIndex ?>')" class="move-btn">Move</button>
                                            <button onclick="toggleEditOptions('remove-btn-container-<?= $index ?>-<?= $memIndex ?>', 're-move-btn-container-<?= $index ?>-<?= $memIndex ?>')" class="remove-btn">Remove</button>
                                        </div>
                                        
                                        <?php if (isset($errors["cantmove-{$index}-{$memIndex}"])): ?>
                                            <p class="errormsg"><?= $errors["cantmove-{$index}-{$memIndex}"] ?></p>
                                        <?php endif; ?>
                                    </td>
                                <?php } ?>
                            <?php } ?>
                

                        <!-- ==================================================================== -->
                    </tbody>
                </table>
                        <?php }?>
            </div>

            <div class="confirm-btn-container">
                <form class="hidden-group-form" id="groupings" action="/groups" method="post">
                    <input type="hidden" name="encodedGroup" value="<?= htmlspecialchars($encoded, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="hidden" name="finalize" value="finalize">

                    <?php if (! empty($decodedRemoved)): ?>
                        <input type="hidden" name="encodedRemoved" value="<?= htmlspecialchars($encodedRemoved, ENT_QUOTES, 'UTF-8') ?>">
                    <?php endif; ?>
                    <input type="hidden" name="room_id" value="<?= $room_id ?>">
                    <button class="confirm-btn" type="submit">Confirm Groups</button>
                </form>
            </div>
        </div>

    </main>



    <?php if (! isset($errors["removednotempty"])): ?>
        <script src="assets/js/effects.js"></script>
    <?php elseif (isset($errors["removednotempty"])): ?>
        <script src="/assets/js/effects.js"></script>
    <?php endif; ?>

    

</body>


</html>