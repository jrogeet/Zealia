<form method="POST" action="/group">
    <div>
    <?php 
        dd($groups);
        dd($_POST);
    ?>
        <input type="number" name="groupNum">
    </div>

    <input type="submit" name="group" value="group" class="">
</form>


