<footer>
        <div class="footer-container">
            <div class="footer-content">
                <div class="footer-logo">

                    <a href="/index.html" class="logo-link">
                        <span class="logo-footer nav-select">A
                            <span class="logo-span mbti-m">M</span>
                                <span class="logo-span mbti-b">B</span>
                                <span class="logo-span">I</span><span class="logo-span">
                                    <span class="logo-span mbti-t">T</span>
                                    <span class="logo-span mbti-i">I</span>
                                    O N</span></a>

                    <span class="tagline">Forging Stronger Teams with MBTI</span>
                </div>

                <div class="footer-nav">
                    <span class="footer-nav-header">General</span>
                    <ul class="footer-nav-ul">
                        <li class="footer-nav-li"><a href="/home" class="nav-btn btn-home">Home</a></li>
                        <li class="footer-nav-li"><a href="/dashboard" class="nav-btn btn-create">Dashboard</a></li>
                        <li class="footer-nav-li"><a href="/about" class="nav-btn btn-about">About</a></li>
    
                    </ul>
                </div>

                <div class="footer-contact">
                    <span class="footer-contact-header">Get in touch</span>
                    <ul class="footer-contact-ul">
                        <li class="footer-contact-li">Email:ambitionxmbti@gmail.com</li>
                        <li class="footer-contact-li">Number: (+63) 9*********</li>
                    </ul>
                    <a href="/submit-ticket" class="submit-ticket-txt">Submit a Ticket</a>
                </div>
            </div>
        </div>
</footer>