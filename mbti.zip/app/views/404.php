


<?php require_once '../app/views/partials/head.php' ?>

<body>


    <main>
    <?php

        echo '404 error lol <br>';
        echo 'Page Not Found';

    ?>
    <span>Go back to <a >Dashboard</a></span>
    </main>


</body>
