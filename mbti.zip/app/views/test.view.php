<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personality Test</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Personality Test</h1>
    <main id="main"></main>

    <div class="intro" id="introDiv">
        <input id="sID" type="number" placeholder="Student ID" required>
        <input id="sName" type="text" placeholder="Surname" required>
        <input id="section" type="text" placeholder="Section" required>
        <button class="start" id="startButton">Start Test</button>
    </div>

    <div class="choices" id="choicesDiv">
        <button class="checkboxes" id="SD">Strongly Disagree</button>
        <button class="checkboxes" id="D">Disagree</button>
        <button class="checkboxes" id="SLD">Slighty Disagree</button>
        <button class="checkboxes" id="N">Neutral</button>
        <button class="checkboxes" id="SLA">Slightly Agree</button>
        <button class="checkboxes" id="A">Agree</button>
        <button class="checkboxes" id="SA">Strongly Agree</button>
    </div>

    <div class="back" id="backDiv">
        <button class="prev" id="prevQ" onclick="PrevQ()">Back</button>
    </div>

    <div class="result-page" id="resultPage">

        <div class="result-bar" id="extroBar"> <!--EXTRO BAR-->
            <div class="fill" style="width: 75%;"></div>
        </div>

        <div class="percentage-label">  <!--EXTRO LABEL-->
            Extroversion: <span id="extroversion"></span> | Introversion: <span id="introversion"></span>
        </div>

        <div class="result-bar" id="intuiBar"> <!--INTUI BAR-->
            <div class="fill" style="width: 75%;"></div>
        </div>

        <div class="percentage-label">  <!--INTUI LABEL-->
            Intuition: <span id="intuition"></span> | Sensing: <span id="sensing"></span>
        </div>

        <div class="result-bar" id="feelBar"> <!--FEEL BAR-->
            <div class="fill" style="width: 75%;"></div>
        </div>

        <div class="percentage-label">  <!--FEEL LABEL-->
            Feeling: <span id="feeling"></span> | Thinking: <span id="thinking"></span>
        </div>

        <div class="result-bar" id="judgeBar"> <!-- JUDGE BAR-->
            <div class="fill" style="width: 75%;"></div>
        </div>

        <div class="percentage-label">  <!--JUDGE LABEL-->
            Judging: <span id="judging"></span> | Perceiving: <span id="perceiving">25%</span>
        </div>

        <div>
            <h1 id="MBTI"></h1>
        </div>
        
    </div>
    
    <script src="questions.js"></script>
</body>
</html>
