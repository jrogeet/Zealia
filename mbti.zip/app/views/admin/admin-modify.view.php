<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personality Test</title>
    <link rel="stylesheet" type="text/css" href="/assets/css/partials/navbar.css">
    <link rel="stylesheet" type="text/css"  href="assets/css/admin/admin-modify.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/partials/footer.css">
</head>

<style>
    <?php include base_path('public/assets/css/shared-styles.css'); ?>

</style>

<body>
    <?php view('partials/nav.view.php'); ?>

    <main class="main-container">
        <form class="modify-actual-form" action="/admin-modify-account" method="post">
            <?php if($_GET['t'] === 'sid'): ?>
                <input name="id_change" type="number" placeholder="Student ID Number" required>
                <input type="hidden" name="school_id" value="<?= $_GET['sid'] ?>">
            <?php elseif($_GET['t'] === 'ln'): ?>
                <input name="l_name" type="text"  placeholder="Last Name"  required>
                <input type="hidden" name="school_id" value="<?= $_GET['sid'] ?>">
            <?php elseif($_GET['t'] === 'fn'): ?>
                <input name="f_name" type="text"  placeholder="First Name">
                <input type="hidden" name="school_id" value="<?= $_GET['sid'] ?>">
            <?php elseif($_GET['t'] === 'pt'): ?>
                <label for="personality_type">Select MBTI Type</label>
                    <select name="personality_type" id="reason" placeholder="Select Category" required>
                        <option value="null">N/A</option>
                        <option value="INFJ">INFJ</option>
                        <option value="INTJ">INTJ</option>
                        <option value="INTP">INTP</option>
                        <option value="INFP">INFP</option>
                        <option value="ISTJ">ISTJ</option>
                        <option value="ISTP">ISTP</option>
                        <option value="ISFJ">ISFJ</option>
                        <option value="ISFP">ISFP</option>
                        <option value="ENTJ">ENTJ</option>
                        <option value="ENTP">ENTP</option>
                        <option value="ENFJ">ENFJ</option>
                        <option value="ENFP">ENFP</option>
                        <option value="ESTJ">ESTJ</option>
                        <option value="ESTP">ESTP</option>
                        <option value="ESFJ">ESFJ</option>
                        <option value="ESFP">ESFP</option>
                    </select>

                    <input type="hidden" name="school_id" value="<?= $_GET['sid'] ?>">
            <?php elseif($_GET['t'] === 'e'): ?>
                <input type="email" name="email" placeholder="Email">
                <input type="hidden" name="school_id" value="<?= $_GET['sid'] ?>">
            <?php endif; ?>
            <button type="submit">Update</button>
        </form>
    </main>
    <?php view('partials/footer.php')?>

</body>