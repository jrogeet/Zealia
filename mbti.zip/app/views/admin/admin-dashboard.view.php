<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" type="text/css"  href="assets/css/admin/admin-dashboard.css">
</head>
<style>
    <?php 
        
        include base_path('public/assets/css/shared-styles.css');

    ?>

</style>
<body>
    <?php // dd($professors);?>
    <nav class="admin-nav-tabs">
        <div class="title-container">
            <a class="menu-title-anchor" href="/admin">
                <span class="menu-title title-text">A
                    <span class="title-text title-span mbti-m">M</span>
                    <span class="title-text title-span mbti-b">B</span>
                    I
                    <span class="title-text title-span mbti-t">T</span>
                    <span class="title-text title-span mbti-i">I</span>
                    O N
                </span>
            </a>

            <span>Admin</span>
        </div>

        <ul class="admin-nav-tabs-ul">
            <li class="admin-nav-tabs-li">
                <a onclick="adminTabs('dashboard')" class="admin-nav-tabs-a">Dashboard</a>
            </li>

            <li class="admin-nav-tabs-li">
                <a onclick="adminTabs('accounts')" class="admin-nav-tabs-a">Accounts</a>
            </li>

            <li class="admin-nav-tabs-li">
                <a onclick="adminTabs('rooms')" class="admin-nav-tabs-a">Rooms</a>
            </li>

            <li class="admin-nav-tabs-li">
                <a onclick="adminTabs('submit-ticket')" class="admin-nav-tabs-a">Tickets</a>
            </li>

            <li class="admin-nav-tabs-li">
                <a href="/" class="admin-nav-tabs-a">User Page</a>
            </li>
        </ul>
    </nav>

    <main>
        <div class="dashboard-container">
            <!-- UPPER -->
            <div class="accounts-global-count">
                <div onclick="adminTabs('accounts')" class="accounts-count-total-wrap">
                    <span class="accounts-count-total-title count-total-title">Total No. of Accounts: </span>
                    <span class="accounts-count-total-number count-total-number">
                        <?= count($accounts) ?>
                    </span>
                </div>

                <div class="stuprof-count-total-wrap">
                    <div onclick="adminTabs('accounts')" class="students-count-total-wrap">
                        <span class="students-count-total-title count-total-title">Total No. of Students: </span>
                        <span class="students-count-total-number count-total-number">
                            <?= count($students) ?> 
                        </span>
                    </div>

                    <div onclick="adminTabs('accounts')" class="professors-count-total-wrap">
                        <span class="professors-count-total-title count-total-title">Total No. of Professors: </span>
                        <span class="professors-count-total-number count-total-number">
                            <?= count($professors) ?>
                        </span>
                    </div>
                </div>
            </div>

            <!-- LOWER -->

            <div class="recents-container">
                <div onclick="adminTabs('accounts')" class="accounts-recents">
                    <span class="accounts-recents-title">Recently Created Accounts</span>
                    <table class="accounts-recents-table">
                        <thead class="accounts-recents-thead">
                            <tr class="accounts-recents-head-tr">
                                <th class="accounts-recents-th">School ID</th>
                                <th class="accounts-recents-th">Name</th>
                                <th class="accounts-recents-th">Email</th>
                                <th class="accounts-recents-th">Registered from</th>
                                <th class="accounts-recents-th">Activation</th>
                            </tr>
                        </thead>

                        <tbody class="accounts-recents-tbody">
                            <?php foreach($recentAccounts as $account) {?> 
                                <tr class="accounts-recents-body-tr">
                                    <td class="accounts-recents-td"><?= $account['school_id'] ?></td>
                                    <td class="accounts-recents-td"><?= $account['l_name'] ?>, <?= $account['f_name'] ?></td>
                                    <td class="accounts-recents-td"><?= $account['email'] ?></td>
                                    <td class="accounts-recents-td"><?= $account['daysAgo'] ?> days, <?= $account['hoursAgo'] ?> hours, <?= $account['minutesAgo'] ?> minutes ago</td>
                                    <td class="accounts-recents-td">
                                        <?php if(isset($account['account_activation_hash'])): ?>
                                                <span>Not Yet Activated</span>
                                        <?php else:?>
                                                <span>Already Activated</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php }?>
                        </tbody>
                    </table>
                </div>

                <div onclick="adminTabs('rooms')" class="rooms-recents">
                    <span class="rooms-recents-title">Recently Created Rooms</span>
                    <table class="rooms-recents-table">
                        <thead class="rooms-recents-thead">
                            <tr class="rooms-recents-head-tr">
                                <th class="rooms-recents-th">Room ID</th>
                                <th class="rooms-recents-th">Room Name</th>
                                <th class="rooms-recents-th">Professor Name</th>
                                <th class="rooms-recents-th">Professor ID</th>
                                <th class="rooms-recents-th">Room Code</th>
                                <th class="rooms-recents-th">Created from</th>
                            </tr>
                        </thead>

                        <tbody class="rooms-recents-tbody">
                            <?php foreach($recentRooms as $room) { ?>
                                <tr class="rooms-recents-body-tr">
                                    <td class="rooms-recents-td"><?= $room['room_id'] ?></td>
                                    <td class="rooms-recents-td"><?= $room['room_name'] ?></td>
                                    <?php foreach($professors as $professor) { ?>
                                        <?php if($professor['school_id'] == $room['school_id']) { ?>
                                            <td class="rooms-recents-td"><?= $professor['f_name'] . ' ' . $professor['l_name'] ?></td>
                                        <?php } ?>
                                    <?php } ?>
                                    <td class="rooms-recents-td"><?= $room['school_id'] ?></td>
                                    <td class="rooms-recents-td"><?= $room['room_code'] ?></td>
                                    <td class="rooms-recents-td"><?= $room['daysAgo'] ?> days, <?= $room['hoursAgo'] ?> hours, <?= $room['minutesAgo'] ?> minutes ago</td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>



        <div class="accounts-list">
            <div class="accounts-list-container">
                <h1 class="accounts-list-title accounts-recents-title">Accounts</h1> 

                <span class="users-count-display">Total No. of Users: </span>


                <div class="tabs-container">
                    <div class="room-tabs">
                        <button onclick="toggleEditOptions('students-accounts-container', 'professors-accounts-container')"  class='inner-admin-tabs'>
                            <span class="tabs-text">Students</span>
                        </button>

                        <button onclick="toggleEditOptions('professors-accounts-container', 'students-accounts-container')"  class='inner-admin-tabs'>
                            <span class="tabs-text">Professors</span>
                        </button>
                    </div>   
                    
                </div>

                <div class="students-accounts-container" id="students-accounts-container">
                    <span>Students</span>
                    <table class="students-table accounts-recents-table">
                        <thead class="accounts-recents-thead">
                            <tr class="accounts-recents-head-tr">
                                <th class="accounts-recents-th">School ID</th>
                                <th class="accounts-recents-th">Last Name</th>
                                <th class="accounts-recents-th">First Name</th>
                                <th class="accounts-recents-th">Personality Type</th>
                                <th class="accounts-recents-th">Email</th>
                                <th class="accounts-recents-th">Password</th>
                                <th class="accounts-recents-th">Registration Date</th>
                                <th class="accounts-recents-th">Activation</th>
                            </tr>
                        </thead>

                        <tbody class="accounts-recents-tbody">
                            <?php foreach($students as $student) {?> 
                                <tr class="accounts-recents-body-tr">
                                    <td class="accounts-recents-td">
                                        <a href="/admin-modify?t=sid&sid=<?= $student['school_id'] ?>">
                                            <?= $student['school_id'] ?>
                                        </a>
                                    </td>
                                    
                                    <td class="accounts-recents-td">
                                        <a href="/admin-modify?t=ln&sid=<?= $student['school_id'] ?>">
                                            <?= $student['l_name'] ?>
                                        </a>
                                    </td>
                                    <td class="accounts-recents-td">
                                        <a href="/admin-modify?t=fn&sid=<?= $student['school_id'] ?>">
                                            <?= $student['f_name'] ?>
                                        </a>
                                    </td>
                                    <td class="accounts-recents-td">
                                        <a href="/admin-modify?t=pt&sid=<?= $student['school_id'] ?>">
                                            <?php if (is_null($student['personality_type'])) {
                                                echo 'N/A';
                                            } elseif (!is_null($student['personality_type']))
                                                echo $student['personality_type'];
                                            ?>
                                        </a>
                                    </td>
                                    <td class="accounts-recents-td">
                                        <a href="/admin-modify?t=e&sid=<?= $student['school_id'] ?>">
                                            <?= $student['email'] ?>
                                        </a>
                                    </td>

                                    <td class="accounts-recents-td">
                                        <form action="/admin" method="post">   
                                            <input type="hidden" name="school_id" value="<?= $student['school_id'] ?>">
                                            <input type="hidden" name="change_pass" value="change_pass">
                                            <button class="changepass-btn">Change Password</button>
                                        </form>
                                    </td>
                                    <td class="accounts-recents-td"><?= $student['reg_date'] ?></td>
                                    <td class="accounts-recents-td">
                                        <?php if(isset($student['account_activation_hash'])): ?>
                                            <form action="/admin" method="post">   
                                                <input type="hidden" name="school_id" value="<?= $student['school_id'] ?>">
                                                <input type="hidden" name="activate" value="activate">
                                                <button class="activation-btn">Activate</button>
                                            </form>
                                        <?php else:?>
                                                <span>Already Activated</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php }?>
                        </tbody>
                    </table>
                </div>

                <div class="students-accounts-container" id="professors-accounts-container" style="display: none;">
                    <span>Professors</span>
                    <table class="students-table accounts-recents-table">
                        <thead class="accounts-recents-thead">
                            <tr class="accounts-recents-head-tr">
                                <th class="accounts-recents-th">School ID</th>
                                <th class="accounts-recents-th">Last Name</th>
                                <th class="accounts-recents-th">First Name</th>
                                <th class="accounts-recents-th">Personality Type</th>
                                <th class="accounts-recents-th">Email</th>
                                <th class="accounts-recents-th">Password</th>
                                <th class="accounts-recents-th">Registration Date</th>
                                <th class="accounts-recents-th">Activation</th>
                            </tr>
                        </thead>

                        <tbody class="accounts-recents-tbody">
                            <?php foreach($professors as $professor) {?> 

                                    <tr class="accounts-recents-body-tr">
                                            <td class="accounts-recents-td">
                                                <a href="/admin-modify?t=sid&sid=<?= $professor['school_id'] ?>">
                                                    <?= $professor['school_id'] ?>
                                                </a>
                                            </td>
                                            
                                            <td class="accounts-recents-td">
                                                <a href="/admin-modify?t=ln&sid=<?= $professor['school_id'] ?>">
                                                    <?= $professor['l_name'] ?>
                                                </a>
                                            </td>
                                            <td class="accounts-recents-td">
                                                <a href="/admin-modify?t=fn&sid=<?= $professor['school_id'] ?>">
                                                    <?= $professor['f_name'] ?>
                                                </a>
                                            </td>
                                            <td class="accounts-recents-td">
                                                <a href="/admin-modify?t=pt&sid=<?= $professor['school_id'] ?>">
                                                    <?php if (is_null($professor['personality_type'])) {
                                                        echo 'N/A';
                                                    } elseif (!is_null($professor['personality_type']))
                                                        echo $professor['personality_type'];
                                                    ?>
                                                </a>
                                            </td>
                                            <td class="accounts-recents-td">
                                                <a href="/admin-modify?t=e&sid=<?= $professor['school_id'] ?>">
                                                    <?= $professor['email'] ?>
                                                </a>
                                            </td>

                                            <td class="accounts-recents-td">
                                                <form action="/admin" method="post">   
                                                    <input type="hidden" name="school_id" value="<?= $professor['school_id'] ?>">
                                                    <input type="hidden" name="change_pass" value="change_pass">
                                                    <button class="changepass-btn">Change Password</button>
                                                </form>
                                            </td>
                                        <td class="accounts-recents-td"><?= $student['reg_date'] ?></td>
                                        <td class="accounts-recents-td">
                                            <?php if(isset($student['account_activation_hash'])): ?>
                                                <form action="/admin" method="post">   
                                                    <input type="hidden" name="school_id" value="<?= $professor['school_id'] ?>">
                                                    <input type="hidden" name="activate" value="activate">
                                                    <button class="activation-btn">Activate</button>
                                                </form>
                                            <?php else:?>
                                                    <span>Already Activated</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </a>
                            <?php }?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="rooms-list">
            <h1>Rooms</h1>

            <table>
                <thead>
                    <tr>
                        <th>Room ID</th>
                        <th>Room Name</th>
                        <th>Room Code</th>
                        <th>Professor Name</th>
                        <th>Professor ID</th>

                    </tr>
                </thead>

                <tbody>
                    <?php foreach($rooms as $room) {?>
                        <tr>
                            <td><?= $room['room_id'] ?></td>
                            <td><?= $room['room_name'] ?></td>
                            <td><?= $room['room_code'] ?></td>
                            <?php foreach($professors as $professor) {?>
                                <?php if($professor['school_id'] == $room['school_id']) {?>
                                    <td><?= $professor['f_name'] . ' ' . $professor['l_name'] ?></td>
                                <?php }?>
                            <?php }?>
                            <td><?= $room['school_id'] ?></td>

 
                        </tr>
                    <?php }?>
                </tbody>
            </table>
        </div>

        <div class="submit-ticket-container">
            <h1 class="submit-ticket-title">Submit Ticket</h1>
            <table>
                <thead>
                    <tr>
                        <th>Ticket ID</th>
                        <th>Reason</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>School ID</th>
                        <th>Email</th>
                    </tr>
                </thead>

                <tbody>
                    <?php foreach($tickets as $ticket) {?>
                        <tr>
                            <td><?= $ticket['ticket_id'] ?></td>
                            <td><?= $ticket['f_name'] ?></td>
                            <td><?= $ticket['l_name'] ?></td>
                            <td><?= $ticket['year_section'] ?></td>
                            <td><?= $ticket['school_id'] ?></td>
                            <td><?= $ticket['category'] ?></td>
                            <td><?= $ticket['email'] ?></td>
                        </tr>
                    <?php }?>
                </tbody>
            </table>
        </div>
        
        <div class="my-account">
            <h1>My account</h1>
        </div>

    </main>



    <script src="assets/js/effects.js"></script>
</body>
</html>
