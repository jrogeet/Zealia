

<div class="accounts-list">
            <h1 class="accounts-list-title">Accounts</h1> 

            <span class="users-count-display">Total No. of Users: </span>


            <div class="tabs-container">
                        <!-- <form method="POST" action=""> -->
                <div class="room-tabs">
                    <button onclick="inneradminTabs('students')"  class='inner-admin-tabs'>
                        <span class="tabs-text">Students</span>
                    </button>

                    <button onclick="inneradminTabs('professors')"  class='inner-admin-tabs'>
                        <span class="tabs-text">Professors</span>
                    </button>
                </div>
                            
                        <!-- </form> -->
            </div>
        </div>

        <div class="rooms-list">
            <h1>Rooms</h1>
        </div>
        
        <div class="my-account">
            <h1>Rooms</h1>
        </div>