<!-- ACCOUNT SETTINGS PAGE  / PROFILE PAGE -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AMBITION</title>
    <link rel="stylesheet" type="text/css" href="assets/css/about.css">
    <link rel="stylesheet" type="text/css" href="assets/css/partials/navbar.css">
    <link rel="stylesheet" type="text/css" href="assets/css/partials/footer.css">
</head>


<style>
    <?php 
        
        include base_path('public/assets/css/shared-styles.css');

    ?>

</style>
<body>
    <?php if(isset($notifications)){
        view('partials/nav.view.php', ['notifications' => $notifications]);
    } elseif (! isset($notifications)) {
        view('partials/nav.view.php');
    }
    ?>


    <main>
        <section class="section-about-container">
            <div class="about-hero">
                <h1 class="about-header">About</h1>
                <!-- <p class="about-para">Our platform uses the MBTI to build productive teams by utilizing individual personalities. Members are paired with roles that correlate with their innate talents, such as programming, analysis, or design, using MBTI assessment. Furthermore, the method finds natural leaders within teams based on MBTI profiles, assuring a balanced mix of abilities and leadership attributes. Join us as we integrate personality and teamwork science to maximize team potential.
                </p> -->
                <!-- <p class="about-para">Our platform maximizes team potential by leveraging the MBTI to build productive teams aligned with individual personalities and talents. Through MBTI assessments, members are matched with roles like programming, analysis, or design that suit their inherent skills. Moreover, it identifies natural leaders within teams based on MBTI profiles, ensuring a balanced blend of abilities and leadership traits. Join us to explore the integration of personality and teamwork science for optimal team performance.</p> -->
                <p class="about-para">Our platform uses MBTI to align teams with individual personalities and talents, matching members to roles that suit their skills while identifying natural leaders based on their profiles, ensuring a balanced team. Explore how personality integration optimizes teamwork for peak performance.</p>
            </div>
        </section>


        <section class="section-roles-container">
            <div class="roles-container">
                    <div class="roles-how">
                        <h2 class="roles-header" id="how-it-works">How it works</h2>
                        <p class="roles-para">The professor will create rooms where student can join, the professor can group students that already have an MBTI type or had taken the personality test.</p>
                    </div>

                    <div class="roles-wrap">
                        <div class="roles">
                            <img class="roles-img" src="assets/images/x.png" alt="" >

                            <div class="roles-text">
                                <span class="role-title analyst">Analyst</span>
                                <p class="role-description">Analysts interpret information and trends, providing valuable insights that inform decision-making processes and improve workflows. They often collaborate across departments or subjects to ensure a comprehensive understanding of the data.</p>
                            </div>
                        </div>
                        
                        <div class="roles">
                            <div class="roles-text">
                                <span class="role-title designer">Designer</span>
                                <p class="role-description">Programmers develop and maintain systems, creating and refining structures to ensure functionality and reliability. Their work involves problem-solving and collaboration to implement technical solutions efficiently.</p>
                            </div>

                            <img class="roles-img" src="assets/images/x.png" alt="" >
                        </div>

                        <div class="roles">
                            <img class="roles-img" src="assets/images/x.png" alt="" >
                            <div class="roles-text">
                                <span class="role-title programmer">Programmer</span>
                                <p class="role-description">Designers focus on creating user-friendly and visually appealing experiences, whether in presentations, projects, or products. They collaborate with stakeholders to understand needs and preferences, ensuring the final output aligns with objectives and resonates with the audience.</p>
                            </div>
                        </div>
                    </div>
            </div>

        </section>
    
        <section class="team">
            <div class="team-container">
                <h2 class="team-header">MEET THE TEAM</h2>

                <div class="team-deck">
                    <div class="llamas-card-container">
                        <div class="team-card">
                            <div class="team-card-front">
                                <img src="assets/images/Team-Cards/Llamas-Card-Black.png" class="team-card-img" alt="">
                            </div>

                            <div class="team-card-back">
                                <img src="assets/images/Team-Cards/Llamas-Card-Reverse.png" class="team-card-img" alt="">
                            </div>
                        </div>
                    </div>

                <div class="gregorio-card-container">
                    <div class="team-card">
                        <div class="team-card-front">
                            <img src="assets/images/Team-Cards/Gregorio-Card-Black.png" class="team-card-img" alt="">
                        </div>

                        <div class="team-card-back">
                            <img src="assets/images/Team-Cards/Gregorio-Card-Reverse.png" class="team-card-img" alt="">
                        </div>
                    </div>
                </div>

                <div class="ganon-card-container">
                    <div class="team-card">
                        <div class="team-card-front">
                            <img src="assets/images/Team-Cards/Ganon-Card-Black.png" class="team-card-img" alt="">
                        </div>

                        <div class="team-card-back">
                            <img src="assets/images/Team-Cards/Ganon-Card-Reverse.png" class="team-card-img" alt="">
                        </div>
                    </div>
                </div>

                <div class="turqueza-card-container">
                    <div class="team-card">
                        <div class="team-card-front">
                            <img src="assets/images/Team-Cards/Turqueza-Card-Black.png" class="team-card-img" alt="">
                        </div>

                        <div class="team-card-back">
                            <img src="assets/images/Team-Cards/Turqueza-Card-Reverse.png" class="team-card-img" alt="">
                        </div>
                    </div>
                </div>
            </div>

            </div>
        </section>

    </main>

    <?php view('partials/footer.php')?>

    <script src="assets/js/effects.js"></script>
</body>

</html>