<?php

$router->get('/', 'controller/index.php');
$router->get('/home', 'controller/home.php');
$router->get('/about', 'controller/about.php');

$router->post('/nav', 'model/clear-notifications.php');

$router->get('/account', 'controller/account/account.php')->only('auth');
$router->post('/account', 'model/account/change.php')->only('auth');

$router->get('/test', 'controller/account/test.php')->only('auth');
$router->post('/test', 'model/account/test-page.php')->only('auth');

$router->get('/profile', 'controller/account/profile.php')->only('auth');

$router->get('/dashboard', 'controller/rooms/dashboard.php')->only('auth');
$router->post('/dashboard', 'model/rooms/store.php')->only('auth');

$router->get('/room', 'controller/rooms/show.php')->only('auth');
$router->post('/room', 'model/rooms/request.php');
$router->patch('/room', 'model/rooms/update.php');
$router->delete('/room', 'model/rooms/destroy.php');

$router->get('/groups', 'controller/rooms/group/results.php')->only('auth');
$router->post('/groups', 'controller/rooms/group/results.php')->only('auth');
$router->patch('/groups', 'controller/rooms/group/results.php')->only('auth');
$router->delete('/groups', 'controller/rooms/group/results.php')->only('auth');

$router->get('/register', 'controller/auth/registration/create.php')->only('guest');
$router->post('/register', 'model/auth/registration/store.php')->only('guest');
$router->get('/activate-account', 'controller/auth/registration/success-signup.php')->only('guest');
$router->get('/active-success', '/model/auth/registration/success-activation.php')->only('guest');

$router->get('/login', 'controller/auth/login/create.php')->only('guest');
$router->post('/login', 'model/auth/login/store.php')->only('guest');
$router->delete('/login', 'model/auth/login/destroy.php')->only('auth');

$router->get('/forgot-password', 'controller/auth/login/forgot.php')->only('guest');
$router->post('/forgot-password', 'model/auth/login/forgot.php')->only('guest');
$router->get('/reset-password', 'controller/auth/login/reset-password.php')->only('guest');
$router->post('/reset-password', 'model/auth/login/process-reset-password.php')->only('guest');


$router->get('/admin', 'controller/admin/admin-dashboard.php')->only('auth');
$router->post('/admin', 'controller/admin/admin-changepass.php')->only('auth');

$router->get('/admin-modify', 'controller/admin/admin-modify.php')->only('auth');
$router->post('/admin-modify-account', 'model/admin/admin-modify.php')->only('auth');
$router->post('/admin-change-password', 'model/admin/admin-changepass.php')->only('auth');

$router->get('/submit-ticket', 'controller/admin/submit-ticket.php');
$router->post('/submit-ticket', 'model/admin/submit-ticket.php');
