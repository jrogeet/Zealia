const leadPrio = ["ESTJ", "ISTJ", "ENTJ", "INTJ", "ENTP", "INTP", "ESFJ", "ENFJ", "ISFJ", "INFJ", "ENFP", "ESTP", "ISTP", "INFP", "ISFP", "ESFP"];
const anPrio = ["ENFJ", "ENFP", "ENTJ", "ENTP", "INFJ", "INFP", "INTJ", "INTP"];
const progPrio = ["ISTJ", "INTJ", "ESTJ", "ISTP", "ESTP", "ISFJ", "ESFJ", "ISFP", "ESFP"];
const desPrio = ["INTJ", "INTP", "ENTJ", "ENTP", "ISTJ", "ISFJ", "ESTJ", "ESFJ", "ISTP", "INFJ", "INFP", "ENFJ", "ENFP", "ISFP", "ESTP", "ESFP"];

let inputValues = ["User1 ENFP", "User2 INTP", "User3 ENFJ", "User4 ENFJ", "User5 ENTJ", "User6 ENFJ", "User7 ISFJ", "User8 ENFP", "User9 ENFP", "User10 ENTJ", "User11 ISFJ", "User12 ESFJ", "User13 ENTP", "User14 ESTJ", "User15 ESTJ", "User16 ESFJ", "User17 INTP", "User18 ENFP", "User19 INFJ", "User20 ISFP", "User21 INFP", "User22 ESFJ", "User23 ISTP", "User24 ESFJ", "User25 ISTJ", "User26 ENTJ", "User27 ENFP", "User28 ISFJ", "User29 ESTJ", "User30 INTJ", "User31 ENFP", "User32 ESTP", "User33 ESFJ", "User34 ESFJ", "User35 ENTP", "User36 ENFJ", "User37 ENTP", "User38 INTP", "User39 INTP", "User40 ISFP", "User41 ISFP", "User42 INTP", "User43 INTJ", "User44 ISTJ", "User45 INTP", "User46 INTJ", "User47 ENTP", "User48 ENTJ", "User49 ESFJ", "User50 ISFJ"];

function assignRoles(inputValues) {
    let students = inputValues.map(value => {
        let [user, type] = value.split(" ");
        return { user, type };
    });

    let teams = [];
    let leaders = [], analysts = [], programmers = [], designers = [];
    let grCount = 0; //add

    if (inputValues.length%4 === 0){ //add
        grCount = inputValues.length/4;
    }else{
        grCount = Math.trunc(inputValues.length/4)+1
    }
    console.log(grCount);

    // Assign roles based on priority
    students.forEach(student => { //edit: 12 -> grCount
        if (leadPrio.includes(student.type) && leaders.length < grCount) {
            leaders.push([student.user, student.type, "Leader"]);
        } else if (anPrio.includes(student.type) && analysts.length < grCount) {
            analysts.push([student.user, student.type, "Analyst"]);
        } else if (progPrio.includes(student.type) && programmers.length < grCount) {
            programmers.push([student.user, student.type, "Programmer"]);
        } else if (desPrio.includes(student.type) && designers.length < grCount) {
            designers.push([student.user, student.type, "Designer"]);
        }
    });


    //pinang debug ko lang to
    /*console.log("Leaders: ", leaders.length);
    for(let x of leaders){
        console.log(x);
    }
    console.log("");
    console.log("analysts: ", analysts.length);
    for(let x of analysts){
        console.log(x);
    }
    console.log("");
    console.log("programmers: ", programmers.length);
    for(let x of programmers){
        console.log(x);
    }
    console.log("");
    console.log("designers: ", designers.length);
    for(let x of designers){
        console.log(x);
    }
    console.log("");*/

    // Form teams
    while (leaders.length || analysts.length || programmers.length || designers.length) {
        let team = [];
        if (leaders.length) team.push(leaders.shift());
        if (analysts.length) team.push(analysts.shift());
        if (programmers.length) team.push(programmers.shift());
        if (designers.length) team.push(designers.shift());
        teams.push(team);
    }
    
    return teams;
}

console.log(assignRoles(inputValues));