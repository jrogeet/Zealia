<?php


define('EXTRAV_INTROVERSION', [
    'You regularly make new friends. (E)',
    'You feel comfortable just walking up to someone you find interesting and striking up a conversation. (E)',
    'You rarely worry about whether you make a good impression on people you meet. (E)',
    'In group conversations, you strongly prefer listening to speaking. (I)',
    'You tend to avoid drawing attention to yourself. (I)',
    'You usually prefer to be around others rather than on your own. (E)',
    'After a long and exhausting week, a lively social event is just what you need. (E)',
    'You avoid making phone calls. (I)',
    'In your social circle, you are often the one who contacts your friends and initiates activities. (E)',
    'You would love a job that requires you to work alone most of the time. (I)',
    'You are vocal and outgoing when expressing your ideas at work or in professional settings. (E)',
    'You enjoy participating in team-based activities. (E)'
  ]);

  define('INTUITION_SENSING', [
    'You spend a lot of your free time exploring various topics that catch your interest. (N)',
    'You are not too interested in discussions about various interpretations of creative works. (S)',
    'You see yourself as more of a visionary than a realist. (N)',
    'You frequently consider alternative approaches that could improve the way things are done. (N)',
    'You do not consider yourself an artistic type. (S)',
    'You have always been fascinated by the question of what, if anything, happens after death. (N)',
    'You become bored or lose interest when the discussion gets highly theoretical. (S)',
    'You enjoy going to art museums. (N)',
    'When faced with unfamiliar problems, you prefer innovative solutions to traditional methods. (N)',
    'You are uncomfortable with ambiguity and strongly prefer simplicity to complexity. (S)',
    'You believe that pondering abstract philosophical questions is a waste of time. (S)',
    'You are very intrigued by things labeled as controversial. (N)'
  ]);

  define('FEELING_THINKING', [
    'Seeing other people cry can easily make you feel like you want to cry too. (F)',
    'You usually stay calm, even under a lot of pressure. (T)',
    'You are very sentimental. (F)',
    'Even a small mistake can cause you to doubt your overall abilities and knowledge. (T)',
    'You find it challenging to relate to people who are primarily guided by their emotions. (T)',
    'Helping others succeed brings you more happiness than your own achievements. (F)',
    'You are prone to worrying that things will take a turn for the worse. (F)',
    'You believe relying more on rationality and less on feelings would improve the world. (T)',
    'You put your own needs first, even when you know someone may be upset. (T)',
    'Your mood can change very quickly. (F)',
    'You believe decision-making should prioritize objectivity over personal values. (T)',
    'You find it easy to empathize with a person whose experiences are very different from yours. (F)',
    'You rarely second-guess the choices that you have made. (T)',
    'You often have a hard time understanding others feelings. (T)',
    'You rarely feel insecure. (F)',
    'You are still bothered by mistakes that you made a long time ago. (F)',
    'Your emotions control you more than you control them. (F)',
    'You take great care not to embarrass others, even when it is their fault. (F)',
    'When someone thinks highly of you, you wonder how long it will take them to feel disappointed in you. (F)',
    'To you, maintaining relationships is more important than winning arguments. (F)',
    'You are willing to give up a good opportunity if you believe someone else needs it more. (F)',
    'You feel confident that things will work out for you. (T)'
  ]);

  define('JUDGING_PERCEIVING', [
    'You often make a backup plan for a backup plan. (J)',
    'You are often told by others that you are very reliable. (J)',
    'You like to use organizing tools like schedules and lists. (J)',
    'You usually prefer just doing what you feel like at any given moment instead of planning a particular daily routine. (P)',
    'You prefer to do your chores before allowing yourself to relax. (J)',
    'You often end up doing things at the last possible moment. (P)',
    'You often find yourself being late to meetings and appointments. (P)',
    'You like to have a to-do list for each day. (J)',
    'You have many routines in your daily life that you generally stick to. (J)',
    'You embrace spontaneity and flexibility, finding joy in adapting to new situations without prior planning. (P)',
    'You often feel overwhelmed. (J)',
    'Before making decisions, especially important ones, you carefully weigh all the options. (J)',
    'You struggle with deadlines. (P)'
  ]);

  define('QUESTIONS', [
  // Extraversion (E) vs Introversion (I)
  "You regularly make new friends. (E)",
  "You feel comfortable just walking up to someone you find interesting and striking up a conversation. (E)",
  "You rarely worry about whether you make a good impression on people you meet. (E)",
  "In group conversations, you strongly prefer listening to speaking. (I)",
  "You tend to avoid drawing attention to yourself. (I)",
  "You usually prefer to be around others rather than on your own. (E)",
  "After a long and exhausting week, a lively social event is just what you need. (E)",
  "You avoid making phone calls. (I)",
  "In your social circle, you are often the one who contacts your friends and initiates activities. (E)",
  "You would love a job that requires you to work alone most of the time. (I)",
  "You are vocal and outgoing when expressing your ideas at work or in professional settings. (E)",
  "You enjoy participating in team-based activities. (E)",
  
  // Intuition (N) vs Sensing (S)
  "You spend a lot of your free time exploring various topics that catch your interest. (N)",
  "You are not too interested in discussions about various interpretations of creative works. (S)",
  "You see yourself as more of a visionary than a realist. (N)",
  "You frequently consider alternative approaches that could improve the way things are done. (N)",
  "You do not consider yourself an artistic type. (S)",
  "You have always been fascinated by the question of what, if anything, happens after death. (N)",
  "You become bored or lose interest when the discussion gets highly theoretical. (S)",
  "You enjoy going to art museums. (N)",
  "When faced with unfamiliar problems, you prefer innovative solutions to traditional methods. (N)",
  "You are uncomfortable with ambiguity and strongly prefer simplicity to complexity. (S)",
  "You believe that pondering abstract philosophical questions is a waste of time. (S)",
  "You are very intrigued by things labeled as controversial. (N)",
  
  // Feeling (F) vs Thinking (T)
  "Seeing other people cry can easily make you feel like you want to cry too. (F)",
  "You usually stay calm, even under a lot of pressure. (T)",
  "You are very sentimental. (F)",
  "Even a small mistake can cause you to doubt your overall abilities and knowledge. (T)",
  "You find it challenging to relate to people who are primarily guided by their emotions. (T)",
  "Helping others succeed brings you more happiness than your own achievements. (F)",
  "You are prone to worrying that things will take a turn for the worse. (F)",
  "You believe relying more on rationality and less on feelings would improve the world. (T)",
  "You put your own needs first, even when you know someone may be upset. (T)",
  "Your mood can change very quickly. (F)",
  "You believe decision-making should prioritize objectivity over personal values. (T)",
  "You find it easy to empathize with a person whose experiences are very different from yours. (F)",
  "You rarely second-guess the choices that you have made. (T)",
  "You often have a hard time understanding others’ feelings. (T)",
  "You rarely feel insecure. (F)",
  "You are still bothered by mistakes that you made a long time ago. (F)",
  "Your emotions control you more than you control them. (F)",
  "You take great care not to embarrass others, even when it is their fault. (F)",
  "When someone thinks highly of you, you wonder how long it will take them to feel disappointed in you. (F)",
  "To you, maintaining relationships is more important than winning arguments. (F)",
  "You are willing to give up a good opportunity if you believe someone else needs it more. (F)",
  "You feel confident that things will work out for you. (T)",
  
  // Judging (J) vs Perceiving (P)
  "You often make a backup plan for a backup plan. (J)",
  "You are often told by others that you are very reliable. (J)",
  "You like to use organizing tools like schedules and lists. (J)",
  "You usually prefer just doing what you feel like at any given moment instead of planning a particular daily routine. (P)",
  "You prefer to do your chores before allowing yourself to relax. (J)",
  "You often end up doing things at the last possible moment. (P)",
  "You often find yourself being late to meetings and appointments. (P)",
  "You like to have a to-do list for each day. (J)",
  "You have many routines in your daily life that you generally stick to. (J)",
  "You embrace spontaneity and flexibility, finding joy in adapting to new situations without prior planning. (P)",
  "You often feel overwhelmed. (J)",
  "Before making decisions, especially important ones, you carefully weigh all the options. (J)",
  "You struggle with deadlines. (P)"
  ]);

  