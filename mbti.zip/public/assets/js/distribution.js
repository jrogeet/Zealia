// *****************************************
//      DISTRIBUTION, INPUT & OUTPUT
// *****************************************
const leadPrio = ["ESTJ", "ISTJ", "ENTJ", "INTJ", "ENTP", "INTP", "ESFJ", "ENFJ", "ISFJ", "INFJ", "ENFP", "ESTP", "ISTP", "INFP", "ISFP", "ESFP"];
const anPrio =   ["ENFJ", "ENFP", "ENTJ", "ENTP", "INFJ", "INFP", "INTJ", "INTP", "ISTP", "ISTJ", "ISFP", "ISFJ", "ESTP", "ESTJ", "ESFP", "ESFJ"];
const progPrio = ["ISTJ", "INTJ", "ESTJ", "ISTP", "ESTP", "ISFJ", "ESFJ", "ISFP", "ENFP", "ESFP", "INFP", "ENFJ", "INFJ", "ENTP", "INTP", "ENTJ"];
const desPrio =  ["INTJ", "INTP", "ENTJ", "ENTP", "ISTJ", "ISFJ", "ESTJ", "ESFJ", "ISTP", "INFJ", "INFP", "ENFJ", "ENFP", "ISFP", "ESTP", "ESFP"];

const confPrio = ['ENFP',
                  'ESTP',
                  'ISTP',
                  'INFP',
                  'ISFP',
                  'ESFP'];

let inputValues = ["User1 ENFP", "User2 INTP", "User3 ENFJ", "User4 ENFJ", "User5 ENTJ", "User6 ENFJ", "User7 ISFJ", "User8 ENFP", "User9 ENFP", "User10 ENTJ", "User11 ISFJ", "User12 ESFJ", "User13 ENTP", "User14 ESTJ", "User15 ESTJ", "User16 ESFJ", "User17 INTP", "User18 ENFP", "User19 INFJ", "User20 ISFP", "User21 INFP", "User22 ESFJ", "User23 ISTP", "User24 ESFJ", "User25 ISTJ", "User26 ENTJ", "User27 ENFP", "User28 ISFJ", "User29 ESTJ", "User30 INTJ", "User31 ENFP", "User32 ESTP", "User33 ESFJ", "User34 ESFJ", "User35 ENTP", "User36 ENFJ", "User37 ENTP", "User38 INTP", "User39 INTP", "User40 ISFP", "User41 ISFP", "User42 INTP", "User43 INTJ", "User44 ISTJ", "User45 INTP", "User46 INTJ", "User47 ENTP", "User48 ENTJ", "User49 ESFJ", "User50 ISFJ"];



 //let inputValues = ["12345678901 ENFP", "23456789012 INTP", "34567890123 ENFJ", "45678901234 ENFJ", "56789012345 ENTJ", "67890123456 ENFJ", "78901234567 ISFJ", "89012345678 ENFP", "90123456789 ENFP", "01234567890 ENTJ", "12345678901 ISFJ", "23456789012 ESFJ", "34567890123 ENTP", "45678901234 ESTJ", "56789012345 ESTJ", "67890123456 ESFJ", "78901234567 INTP", "89012345678 ENFP", "90123456789 INFJ", "01234567890 ISFP", "12345678901 INFP", "23456789012 ESFJ", "34567890123 ISTP", "45678901234 ESFJ", "56789012345 ISTJ", "67890123456 ENTJ", "78901234567 ENFP", "89012345678 ISFJ", "90123456789 ESTJ", "01234567890 INTJ", "12345678901 ENFP", "23456789012 ESTP", "34567890123 ESFJ", "45678901234 ESFJ", "56789012345 ENTP", "67890123456 ENFJ", "78901234567 ENTP", "89012345678 INTP", "90123456789 INTP", "01234567890 ISFP", "12345678901 ISFP", "23456789012 INTP", "34567890123 INTJ", "45678901234 ISTJ", "56789012345 INTP", "67890123456 INTJ", "78901234567 ENTP", "89012345678 ENTJ", "90123456789 ESFJ", "01234567890 ISFJ"];



// let inputValues = [
//     "User1 ISTJ", "User2 ENFP", "User3 ISFP", "User4 ESTJ", "User5 INTP", 
//     "User6 INFJ", "User7 ENFJ", "User8 ISTP", "User9 ESFJ", "User10 INTJ", 
//     "User11 ENTJ", "User12 INFP", "User13 ESTP", "User14 ESFP", "User15 ENTJ", 
//     "User16 ISFJ", "User17 ENTP", "User18 ISTJ", "User19 INTP", "User20 ESFP", 
//     "User21 INFJ", "User22 ENFP", "User23 ISFP", "User24 ESTJ", "User25 INTJ", 
//     "User26 ENTJ", "User27 INFP", "User28 ESTP", "User29 ESFJ", "User30 ISTP", 
//     "User31 ENFJ", "User32 ISFJ", "User33 ENTP", "User34 ISTJ", "User35 INTP", 
//     "User36 INFJ", "User37 ENFP", "User38 ISFP", "User39 ESTJ", "User40 INTJ", 
//     "User41 ENTJ", "User42 INFP", "User43 ESTP", "User44 ESFJ", "User45 ISTP", 
//     "User46 ENFJ", "User47 ISFJ", "User48 ENTP", "User49 ISTJ", "User50 INTP", "User51 INFJ", "User52 ENFJ"
// ];
// edit: made variables global instead of local to assignRoles()
let teams = [];
let leaders = [], analysts = [], programmers = [], designers = [];
let grCount = 0; //add

function clean(x){
    let cont = []


    for (user of inputValues){
        if (x.includes(user)){
            cont.push(user);
        }
    }

    for (const user of cont) {
        const index = inputValues.indexOf(user);
        if (index !== -1) {
            inputValues.splice(index, 1); // Remove the user from inputValues[]
        }
    }
    

}

function addRole(x){
    let role = '';
    if( x == leaders ){
        role = 'Leader';
    }else if( x == analysts){
        role = 'Analyst';
    }else if( x == programmers){
        role = 'Programmer';
    }else if( x == designers){
        role = 'Designer';
    }




    for(index in x){
        x[index] = [x[index].slice(0, -4), x[index].slice(-4,), role];
    }

}

function handleConflict(){

    let mbtis = [];

    for (let group of teams){
        let container = [];
        for (let user in group){
            container.push(group[user][1])
        }
        mbtis.push(container);
    }

    
    
    console.log(mbtis);

}

function printEach(x){
    console.log('print');
    for (let user of x){
        console.log(user);
    }
}

function distribute(role){
    
    let limit = role.length;
    let count = 0;
    for (let index = 0; index <= limit; index++){
        for (let group of teams){
            if (count >= limit){
                break;
            }
            group.push(role[0]);
            role.splice(0,1);
            index++;
            count++;
        }
    }

}

function assignRoles(inputValues) {
    let students = inputValues.map(value => {
        let [user, type] = value.split(" ");
        return { user, type };
    });

    if (inputValues.length%4 === 0){ //add
        grCount = inputValues.length/4;
    }else{
        grCount = Math.trunc(inputValues.length/4)+1
    }
    console.log('Group Count:', grCount);

    // Assign roles
    for (mbti of leadPrio){
        for (user of inputValues){
            if ( user.slice(-4,) == mbti && leaders.length < grCount){
                leaders.push(user);
                continue;
            }
        }
    }

    clean(leaders)
    
    for (mbti of anPrio){
        for (user of inputValues){
            if ( user.slice(-4,) == mbti && analysts.length < grCount){
                analysts.push(user);
                continue;
            }
        }
    }

    clean(analysts)
    
    for (mbti of progPrio){
        for (user of inputValues){
            if ( user.slice(-4,) == mbti && programmers.length < grCount){
                programmers.push(user);
                continue;
            }
        }
    }

    clean(programmers)
    
    for (mbti of desPrio){
        for (user of inputValues){
            if ( user.slice(-4,) == mbti && designers.length < grCount){
                designers.push(user);
                continue;
            }
        }
    }

    clean(designers)
    
    addRole(leaders);
    addRole(analysts);
    addRole(programmers);
    addRole(designers);

    /*while (leaders.length || analysts.length || programmers.length || designers.length) {
        let team = [];
        if (leaders.length) team.push(leaders.shift());
        if (analysts.length) team.push(analysts.shift());
        if (programmers.length) team.push(programmers.shift());
        if (designers.length) team.push(designers.shift());
        teams.push(team);
    }*/

    //grouping

    for (let leader of leaders){
        teams.push([leader]);
    }

    distribute(analysts);
    distribute(programmers);
    distribute(designers);

    handleConflict();

    return teams;
    
}




// console.log(assignRoles(inputValues));


// let groupsResult = assignRoles(inputValues);



// btn1.addEventListener("click", main);

function grouped() {  
    if (document.getElementById("stunotype").value > 0) {
        document.querySelector(".group-btn-container").style.display = "none";
        document.querySelector(".not-tested-container").style.display = "flex";


        // groupsResult = assignRoles(document.getElementById("filteredidnmbti").value);
        // console.log(groupsResult);

        // let jsonGroups = JSON.stringify(groupsResult);

        // document.getElementById("grouped").value = jsonGroups;
        // document.getElementById("groupings").submit();
    } else {
        console.log(typeof inputValues);
        groupsResult = assignRoles(inputValues);
        console.log(groupsResult);
    
        let jsonGroups = JSON.stringify(groupsResult);
    
        document.getElementById("grouped").value = jsonGroups;
        document.getElementById("groupings").submit();
    }
}

function groupedAgain() {
    // groupsResult = assignRoles(document.getElementById("filteredidnmbti").value);
    console.log(typeof inputValues);
    groupsResult = assignRoles(inputValues);
    console.log(groupsResult);

    let jsonGroups = JSON.stringify(groupsResult);

    document.getElementById("grouped").value = jsonGroups;
    document.getElementById("groupings").submit();
}
