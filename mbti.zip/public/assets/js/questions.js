const extraversionIntroversion = [
  'You regularly make new friends. (E)',
  'You feel comfortable just walking up to someone you find interesting and striking up a conversation. (E)',
  'You rarely worry about whether you make a good impression on people you meet. (E)',
  'In group conversations, you strongly prefer listening to speaking. (I)',
  'You tend to avoid drawing attention to yourself. (I)',
  'You usually prefer to be around others rather than on your own. (E)',
  'After a long and exhausting week, a lively social event is just what you need. (E)',
  'You avoid making phone calls. (I)',
  'In your social circle, you are often the one who contacts your friends and initiates activities. (E)',
  'You would love a job that requires you to work alone most of the time. (I)',
  'You are vocal and outgoing when expressing your ideas at work or in professional settings. (E)',
  'You enjoy participating in team-based activities. (E)'
];
  
const intuitionSensing = [
  'You spend a lot of your free time exploring various topics that catch your interest. (N)',
  'You are not too interested in discussions about various interpretations of creative works. (S)',
  'You see yourself as more of a visionary than a realist. (N)',
  'You frequently consider alternative approaches that could improve the way things are done. (N)',
  'You do not consider yourself an artistic type. (S)',
  'You have always been fascinated by the question of what, if anything, happens after death. (N)',
  'You become bored or lose interest when the discussion gets highly theoretical. (S)',
  'You enjoy going to art museums. (N)',
  'When faced with unfamiliar problems, you prefer innovative solutions to traditional methods. (N)',
  'You are uncomfortable with ambiguity and strongly prefer simplicity to complexity. (S)',
  'You believe that pondering abstract philosophical questions is a waste of time. (S)',
  'You are very intrigued by things labeled as controversial. (N)'
];
  
const feelingThinking = [
  'Seeing other people cry can easily make you feel like you want to cry too. (F)',
  'You usually stay calm, even under a lot of pressure. (T)',
  'You are very sentimental. (F)',
  'Even a small mistake can cause you to doubt your overall abilities and knowledge. (T)',
  'You find it challenging to relate to people who are primarily guided by their emotions. (T)',
  'Helping others succeed brings you more happiness than your own achievements. (F)',
  'You are prone to worrying that things will take a turn for the worse. (F)',
  'You believe relying more on rationality and less on feelings would improve the world. (T)',
  'You put your own needs first, even when you know someone may be upset. (T)',
  'Your mood can change very quickly. (F)',
  'You believe decision-making should prioritize objectivity over personal values. (T)',
  'You find it easy to empathize with a person whose experiences are very different from yours. (F)',
  'You rarely second-guess the choices that you have made. (T)',
  'You often have a hard time understanding others feelings. (T)',
  'You rarely feel insecure. (F)',
  'You are still bothered by mistakes that you made a long time ago. (F)',
  'Your emotions control you more than you control them. (F)',
  'You take great care not to embarrass others, even when it is their fault. (F)',
  'When someone thinks highly of you, you wonder how long it will take them to feel disappointed in you. (F)',
  'To you, maintaining relationships is more important than winning arguments. (F)',
  'You are willing to give up a good opportunity if you believe someone else needs it more. (F)',
  'You feel confident that things will work out for you. (T)'
];
  
const judgingPerceiving = [
  'You often make a backup plan for a backup plan. (J)',
  'You are often told by others that you are very reliable. (J)',
  'You like to use organizing tools like schedules and lists. (J)',
  'You usually prefer just doing what you feel like at any given moment instead of planning a particular daily routine. (P)',
  'You prefer to do your chores before allowing yourself to relax. (J)',
  'You often end up doing things at the last possible moment. (P)',
  'You often find yourself being late to meetings and appointments. (P)',
  'You like to have a to-do list for each day. (J)',
  'You have many routines in your daily life that you generally stick to. (J)',
  'You embrace spontaneity and flexibility, finding joy in adapting to new situations without prior planning. (P)',
  'You often feel overwhelmed. (J)',
  'Before making decisions, especially important ones, you carefully weigh all the options. (J)',
  'You struggle with deadlines. (P)'
];
  

const questions = [
  // Extraversion (E) vs Introversion (I)
  "You regularly make new friends. (E)",
  "You feel comfortable just walking up to someone you find interesting and striking up a conversation. (E)",
  "You rarely worry about whether you make a good impression on people you meet. (E)",
  "In group conversations, you strongly prefer listening to speaking. (I)",
  "You tend to avoid drawing attention to yourself. (I)",
  "You usually prefer to be around others rather than on your own. (E)",
  "After a long and exhausting week, a lively social event is just what you need. (E)",
  "You avoid making phone calls. (I)",
  "In your social circle, you are often the one who contacts your friends and initiates activities. (E)",
  "You would love a job that requires you to work alone most of the time. (I)",
  "You are vocal and outgoing when expressing your ideas at work or in professional settings. (E)",
  "You enjoy participating in team-based activities. (E)",
  
  // Intuition (N) vs Sensing (S)
  "You spend a lot of your free time exploring various topics that catch your interest. (N)",
  "You are not too interested in discussions about various interpretations of creative works. (S)",
  "You see yourself as more of a visionary than a realist. (N)",
  "You frequently consider alternative approaches that could improve the way things are done. (N)",
  "You do not consider yourself an artistic type. (S)",
  "You have always been fascinated by the question of what, if anything, happens after death. (N)",
  "You become bored or lose interest when the discussion gets highly theoretical. (S)",
  "You enjoy going to art museums. (N)",
  "When faced with unfamiliar problems, you prefer innovative solutions to traditional methods. (N)",
  "You are uncomfortable with ambiguity and strongly prefer simplicity to complexity. (S)",
  "You believe that pondering abstract philosophical questions is a waste of time. (S)",
  "You are very intrigued by things labeled as controversial. (N)",
  
  // Feeling (F) vs Thinking (T)
  "Seeing other people cry can easily make you feel like you want to cry too. (F)",
  "You usually stay calm, even under a lot of pressure. (T)",
  "You are very sentimental. (F)",
  "Even a small mistake can cause you to doubt your overall abilities and knowledge. (T)",
  "You find it challenging to relate to people who are primarily guided by their emotions. (T)",
  "Helping others succeed brings you more happiness than your own achievements. (F)",
  "You are prone to worrying that things will take a turn for the worse. (F)",
  "You believe relying more on rationality and less on feelings would improve the world. (T)",
  "You put your own needs first, even when you know someone may be upset. (T)",
  "Your mood can change very quickly. (F)",
  "You believe decision-making should prioritize objectivity over personal values. (T)",
  "You find it easy to empathize with a person whose experiences are very different from yours. (F)",
  "You rarely second-guess the choices that you have made. (T)",
  "You often have a hard time understanding others’ feelings. (T)",
  "You rarely feel insecure. (F)",
  "You are still bothered by mistakes that you made a long time ago. (F)",
  "Your emotions control you more than you control them. (F)",
  "You take great care not to embarrass others, even when it is their fault. (F)",
  "When someone thinks highly of you, you wonder how long it will take them to feel disappointed in you. (F)",
  "To you, maintaining relationships is more important than winning arguments. (F)",
  "You are willing to give up a good opportunity if you believe someone else needs it more. (F)",
  "You feel confident that things will work out for you. (T)",
  
  // Judging (J) vs Perceiving (P)
  "You often make a backup plan for a backup plan. (J)",
  "You are often told by others that you are very reliable. (J)",
  "You like to use organizing tools like schedules and lists. (J)",
  "You usually prefer just doing what you feel like at any given moment instead of planning a particular daily routine. (P)",
  "You prefer to do your chores before allowing yourself to relax. (J)",
  "You often end up doing things at the last possible moment. (P)",
  "You often find yourself being late to meetings and appointments. (P)",
  "You like to have a to-do list for each day. (J)",
  "You have many routines in your daily life that you generally stick to. (J)",
  "You embrace spontaneity and flexibility, finding joy in adapting to new situations without prior planning. (P)",
  "You often feel overwhelmed. (J)",
  "Before making decisions, especially important ones, you carefully weigh all the options. (J)",
  "You struggle with deadlines. (P)"
];

const arrList = [extraversionIntroversion, intuitionSensing, feelingThinking, judgingPerceiving];

questions.sort()

let resulta = {};
  
let i = 0;  //generate next question
let cont = '';
let ques = '';
let qType = '';
let prevQType = '';
let latestScore = '';
let scoreCount = 0;

let extroPercentage = 0;
let intuiPercentage = 25;
let feelPercentage = 50;
let judgePercentage = 100;
let percePercentage = 100 - judgePercentage;
let thinkPercentage = 100 - feelPercentage;
let sensePercentage = 100 - intuiPercentage;
let introPercentage = 100 - extroPercentage;

let eScore = 0;
let nScore = 0;
let fScore = 0;
let jScore = 0;

const scoreList = ['eScore', 'nScore', 'fScore', 'jScore'];

var buttons = document.querySelectorAll('.checkboxes');
var question = document.getElementById('main');
var q = document.getElementsByClassName("questions");   



function generateQuestions(arg) {
  let items = "";
  
  items += `<label class="questions">${arg[i]}</label>`;
  i++;
  ques = items;
  qType = ques.slice(-10, -9);
  items = items.replace(' (E)', '');
  items = items.replace(' (I)', '');
  items = items.replace(' (N)', '');
  items = items.replace(' (S)', '');
  items = items.replace(' (F)', '');
  items = items.replace(' (T)', '');
  items = items.replace(' (J)', '');
  items = items.replace(' (P)', '');
  return items;
}
  
function GenQ() { //calls generate questions and pastes it in HTML
  document.querySelector("main").style = "display: flex;";
  document.getElementById("testContainer").style = "display: flex;";
  document.querySelector("main").innerHTML = `<form>${generateQuestions(questions)}</form>`;
}
  
// ----------------------- WAG GALAWIN ^^^ ----------------------------//


function NextQ(){ //functions called on button press
  scoreCount = 0;
  var buttonID = event.target.id;
  backbut.style.display = "inline-block";
  cont = questions[i-1]
  console.log("<==================>");
  i--;
  console.log("i counter",i);
  if (i <= 57){
    i++;
    for (let i = 0; i < arrList.length; i++) { //access for each array containing each questions
    let curArr = arrList[i];
    ques = ques.replace(`<label class="questions">`,"");
    ques = ques.replace(`</label>`,""); 
    console.log("qType: ",qType);
    if (curArr.includes(ques)){ //checks which question group the current question is included in
      switch (i){
        case 0:
          console.log("question is IE");
          console.log("Choice:",buttonID);
          latestScore = 'eScore';
          if (qType === 'E' || prevQType === 'E'){
            prevQType = 'E';
            switch (buttonID){
              case 'SD':
                eScore-=3;
                scoreCount-=3;
                break;
              case 'D':
                eScore-=2;
                scoreCount-=2;
                break;
              case 'SLD':
                eScore-=1;
                scoreCount-=1;
                break;
              case 'N':
                break;
              case 'SLA':
                eScore+=1;
                scoreCount+=3;
                break;
              case 'A':
                eScore+=2;
                scoreCount+=3;
                break;
              case 'SA':
                eScore+=3;
                scoreCount+=3;
                break;
            }
          }else if (qType === 'I' || prevQType === 'I'){
            prevQType = 'I';
            switch (buttonID){
              case 'SD':
                eScore+=3;
                scoreCount+=3;
                break;
              case 'D':
                eScore+=2;
                scoreCount+=2;
                break;
              case 'SLD':
                eScore+=1;
                scoreCount+=1;
                break;
              case 'N':
                break;
              case 'SLA':
                eScore-=1;
                scoreCount-=1;
                break;
              case 'A':
                eScore-=2;
                scoreCount-=2;
                break;
              case 'SA':
                eScore-=3;
                scoreCount-=3;
                break;
            }
          }
          console.log("eScore =",eScore);
          break;
        case 1:
          console.log("question is NS");
          console.log(buttonID);
          latestScore = 'nScore';
          if (qType === 'S' || prevQType === 'S'){
            prevQType = 'S';
            switch (buttonID){
              case 'SD':
                nScore-=3;
                scoreCount-=3;
                break;
              case 'D':
                nScore-=2;
                scoreCount-=2;
                break;
              case 'SLD':
                nScore-=1;
                scoreCount+=1;
                break;
              case 'N':
                break;
              case 'SLA':
                nScore+=1;
                scoreCount+=1;
                break;
              case 'A':
                nScore+=2;
                scoreCount+=2;
                break;
              case 'SA':
                nScore+=3;
                scoreCount+=3;
                break;
            }
          }else if (qType === 'N' || prevQType === 'N'){
            prevQType = 'N';
            switch (buttonID){
              case 'SD':
                nScore+=3;
                scoreCount+=3;
                break;
              case 'D':
                nScore+=2;
                scoreCount+=2;
                break;
              case 'SLD':
                nScore+=1;
                scoreCount+=1;
                break;
              case 'N':
                break;
              case 'SLA':
                nScore-=1;
                scoreCount-=1;
                break;
              case 'A':
                nScore-=2;
                scoreCount-=1;
                break;
              case 'SA':
                nScore-=3;
                scoreCount-=1;
                break;
            }
          }
          console.log("nScore =",nScore);
          break;
        case 2:
          console.log("question is FT");
          console.log(buttonID);
          latestScore = 'fScore';
          if (qType === 'T' || prevQType === 'T'){
            prevQType = 'T';
            switch (buttonID){
              case 'SD':
                fScore-=3;
                scoreCount-=3;
                break;
              case 'D':
                fScore-=2;
                scoreCount-=2;
                break;
              case 'SLD':
                fScore-=1;
                scoreCount-=1;
                break;
              case 'N':
                break;
              case 'SLA':
                fScore+=1;
                scoreCount+=1;
                break;
              case 'A':
                fScore+=2;
                scoreCount+=2;
                break;
              case 'SA':
                fScore+=3;
                scoreCount+=3;
                break;
            }
          }else if (qType === 'F' || prevQType === 'F'){
            prevQType = 'F';
            switch (buttonID){
              case 'SD':
                fScore+=3;
                scoreCount+=3;
                break;
              case 'D':
                fScore+=2;
                scoreCount+=2;
                break;
              case 'SLD':
                fScore+=1;
                scoreCount+=1;
                break;
              case 'N':
                break;
              case 'SLA':
                fScore-=1;
                scoreCount-=1;
                break;
              case 'A':
                fScore-=2;
                scoreCount-=2;
                break;
              case 'SA':
                fScore-=3;
                scoreCount-=3;
                break;
            }
          }
          console.log("fScore:",fScore);
          break;
        case 3:
          console.log("question is JP");
          console.log(buttonID);
          latestScore = 'jScore';
          if (qType === 'P' || prevQType === 'P'){
            prevQType = 'P';
            switch (buttonID){
              case 'SD':
                jScore-=3;
                scoreCount-=3;
                break;
              case 'D':
                jScore-=2;
                scoreCount-=2;
                break;
              case 'SLD':
                jScore-=1;
                scoreCount-=1;
                break;
              case 'N':
                break;
              case 'SLA':
                jScore+=1;
                scoreCount+=1;
                break;
              case 'A':
                jScore+=2;
                scoreCount+=2;
                break;
              case 'SA':
                jScore+=3;
                scoreCount+=3;
                break;
            }
          }else if (qType === 'J' || prevQType === 'J'){
            prevQType = 'J';

            switch (buttonID){
              case 'SD':
                jScore+=3;
                scoreCount+=3;
                break;
              case 'D':
                jScore+=2;
                scoreCount+=2;
                break;
              case 'SLD':
                jScore+=1;
                scoreCount+=1;
                break;
              case 'N':
                break;
              case 'SLA':
                jScore-=1;
                scoreCount-=1;
                break;
              case 'A':
                jScore-=2;
                scoreCount-=2;
                break;
              case 'SA':
                jScore-=3;
                scoreCount-=3;
                break;
            }
          }
          console.log("jScore:",jScore);
          break;
      }
    }
  }
  GenQ()
  }else{
    choices.style.display = "none";
    question.style.display = "none";
    backbut.style.display = "none";
    document.querySelector("main").style = "display: none;";
    document.getElementById("testContainer").style = "display: none;";
    calculatePercentages(eScore);
    calculatePercentages(nScore);
    calculatePercentages(fScore);
    calculatePercentages(jScore);
    resultUpdate();
    resultPage.style.display = "flex";
  }
}//end of NextQ()

buttons.forEach(function(button) {
  button.addEventListener ('click', NextQ)
});

 // ----------------------- FOR CHECKBOXES BUTTON ^^^ ----------------------------//


function StartT(){ //functions called on button press
  intro.style.display = "none";
  choices.style.display = "flex";
  // backbut.style.display = "inline-block";
  GenQ()
}

var buttons = document.querySelectorAll('.start'); 
var intro = document.getElementById("introDiv");
var choices = document.getElementById("choicesDiv");
var backbut = document.getElementById("backDiv");
var prevButton = document.getElementById("prevQ");
var resultPage = document.getElementById("resultPage");

buttons.forEach(function(button) {
  button.addEventListener ('click', StartT)
});

// ------------------------ FOR START BUTTON ^^^ ---------------------------------//

function PrevQ(){
  switch(latestScore){ // checking kung ano last na score para masubtract ung na add before mag prevQ
    case 'eScore':
      eScore = eScore - scoreCount;
      break;
    case 'nScore':
      nScore = nScore - scoreCount;
      break;
    case 'fScore':
      fScore = fScore - scoreCount;
      break;
    case 'jScore':
      jScore = jScore - scoreCount;
      break;
  }
  console.log("previous button was pressed");
  document.getElementById('main').innerHTML = `<form><label class="questions">${cont}</label></form>`; //cont ung pinag lalagyan ko ng previous question
  i--; // para mag align ulit sa tamang counting after prevQ
  ques = cont; // para mag align sa checking kung saang dichotomy papasok ung score ( line 330 )
  backbut.style.display = "none";
}



// ------------------------ FOR PREV BUTTON ^^^ ---------------------------------//


function resultUpdate(){
    
  percePercentage = 100 - judgePercentage;
  thinkPercentage = 100 - feelPercentage;
  sensePercentage = 100 - intuiPercentage;
  introPercentage = 100 - extroPercentage;

  let first = 'E';
  let second = 'N';
  let third = 'F';
  let fourth = 'J';
  let mbti = 'ENFJ'

  if (introPercentage > extroPercentage){
    first = 'I'
  }
  if (sensePercentage > intuiPercentage){
    second = 'S'
  }
  if (thinkPercentage > feelPercentage){
    third = 'T'
  }
  if (percePercentage > judgePercentage){
    fourth = 'P'
  }
  mbti = first+second+third+fourth;
  

  // Set width dynamically based on the variables and set percentage labels FOR EXTRO/INTO
  document.getElementById('extroBar').innerHTML = `
  <div class="fill" style="width: ${extroPercentage}%;"></div>`;
  
  document.getElementById('extroversion').innerText = `${extroPercentage}%`;
  document.getElementById('introversion').innerText = `${introPercentage}%`;
  
  // Set width dynamically based on the variables and set percentage labels FOR INTUI/SENSING
  document.getElementById('intuiBar').innerHTML = `
  <div class="fill" style="width: ${intuiPercentage}%;"></div>`;
  
  document.getElementById('intuition').innerText = `${intuiPercentage}%`;
  document.getElementById('sensing').innerText = `${sensePercentage}%`;
  
  // Set width dynamically based on the variables and set percentage labels FOR FEEL/THINK
  document.getElementById('feelBar').innerHTML = `
  <div class="fill" style="width: ${feelPercentage}%;"></div>`;
  
  document.getElementById('feeling').innerText = `${feelPercentage}%`;
  document.getElementById('thinking').innerText = `${thinkPercentage}%`;
  
  // Set width dynamically based on the variables and set percentage labels FOR EXTRO/INTRO
  document.getElementById('judgeBar').innerHTML = `
  <div class="fill" style="width: ${judgePercentage}%;"></div>`;
  
  document.getElementById('judging').innerText = `${judgePercentage}%`;
  document.getElementById('perceiving').innerText = `${percePercentage}%`;

  document.getElementById('MBTI').innerText = `${mbti}`;

  resultPage.style.display = "flex";

  resulta.mbti = mbti;
  resulta.extroperc = extroPercentage;
  resulta.introperc = introPercentage;
  resulta.intuiperc = intuiPercentage;
  resulta.sensperc = sensePercentage;
  resulta.feelperc = feelPercentage;
  resulta.thinkperc = thinkPercentage;
  resulta.judgeperc = judgePercentage;
  resulta.perceperc = percePercentage;
}

function calculatePercentages(score) {
  const max_score = 24;
  const min_score = -24;

  // Ensure the score is within the valid range
  score = Math.max(min_score, Math.min(max_score, score));

  let calculatedPercentage = ((score + max_score) / (max_score * 2)) * 100;
  let Percentage = 100 - calculatedPercentage;
  let totalScore = `${score}`;
  let dich = '';
  let D1 = '';
  let D2 = '';
  switch (score){
    case eScore:
      D1 = 'Extroversion';
      D2 = 'Introversion';
      dich = 'eScore';
      extroPercentage = calculatedPercentage;
      extroPercentage = extroPercentage.toFixed(2);
      extroPercentage = parseFloat(extroPercentage);

      break;
    case nScore:
      D1 = 'Intuition';
      D2 = 'Sensing';
      dich = 'nScore';
      intuiPercentage = calculatedPercentage;
      intuiPercentage = intuiPercentage.toFixed(2);
      intuiPercentage = parseFloat(intuiPercentage);
      
      break;
    case fScore:
      D1 = 'Feeling';
      D2 = 'Thinking';
      dich = 'fScore';
      feelPercentage = calculatedPercentage;
      feelPercentage = feelPercentage.toFixed(2);
      feelPercentage = parseFloat(feelPercentage);
      
      break;
    case jScore:
      D1 = 'Judging';
      D2 = 'Perceiving';
      dich = 'jScore';
      judgePercentage = calculatedPercentage;
      judgePercentage = judgePercentage.toFixed(2);
      judgePercentage = parseFloat(judgePercentage);
      
      break;
  }

  console.log(`${dich}: ${totalScore}`);
  console.log(`${D1}: ${calculatedPercentage}%`);
  console.log(`${D2}: ${Percentage}%`)
  
}

function confirmResult() {
  let jsonData = JSON.stringify(resulta);
  
  document.getElementById("jsonData").value = jsonData;
  document.getElementById("myForm").submit();
}



/*========================= DATABASE IMPORTANT VALUES ===========================

variable names    |     data type
                  |
extroPercentage   |     float
intuiPercentage   |       ""
feelPercentage    |       ""
judgePercentage   |       ""
                  |
percePercentage   |       ""
thinkPercentage   |       ""
sensePercentage   |       ""
introPercentage   |       ""
                  | 
mbti              |     string        //  mbti result

lagay ko lang to di ko alam pano gumagana ung pag connect sa database eh baka magamit mo to para di ka maguluhan




*/