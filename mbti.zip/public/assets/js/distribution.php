<?php

// *****************************************
// *************  DISTRIBUTION  *************
// *****************************************

const LEADPRIO = array(
  "ESTJ",
  "ISTJ",
  "ENTJ",
  "INTJ",
  "ENTP",
  "INTP",
  "ESFJ",
  "ENFJ",
  "ISFJ",
  "INFJ",
  "ENFP",
  "ESTP",
  "ISTP",
  "INFP",
  "ISFP",
  "ESFP",
);

const CONFPRIO = array("ENFP", "ESTP", "ISTP", "INFP", "ISFP", "ESFP");

const ANPRIO = array(
  array("ENFJ", "ENFP"),
  array("ENTJ", "ENTP"),
  array("INFJ", "INFP"),
  array("INTJ", "INTP"),
);

const PROGPRIO = array(
  "ISTJ",
  "INTJ",
  "ESTJ",
  "ISTP",
  "ESTP",
  "ISFJ",
  "ESFJ",
  "ISFP",
  "ESFP",
);

const DESPRIO = array(
  array("INTJ", "INTP", "ENTJ", "ENTP"),
  array("ISTJ", "ISFJ", "ESTJ", "ESFJ"),
  "ISTP",
  array("INFJ", "INFP", "ENFJ", "ENFP", "ISFP", "ESTP", "ESFP"),
);

$txt2 = $_POST["group"]; // Assuming the group input is submitted via a form with name="group"
$btn1 = $_POST["btn1"]; // Assuming a button with name="btn1" triggers something (unclear in provided code)
$out1 = "";  // To store output text (initially empty)

$inputValues = [
  "User1 ENFP",
  "User2 INTP",
  "User3 ENFJ",
  "User4 ENFJ",
  "User5 ENTJ",
  "User6 ENFJ",
  "User7 ISFJ",
  "User8 ENFP",
  "User9 ENFP",
  "User10 ENTJ",
  "User11 ISFJ",
  "User12 ESFJ",
  "User13 ENTP",
  "User14 ESTJ",
  "User15 ESTJ",
  "User16 ESFJ",
  "User17 INTP",
  "User18 ENFP",
  "User19 INFJ",
  "User20 ISFP",
  "User21 INFP",
  "User22 ESFJ",
  "User23 ISTP",
  "User24 ESFJ",
  "User25 ISTJ",
  "User26 ENTJ",
  "User27 ENFP",
  "User28 ISFJ",
  "User29 ESTJ",
  "User30 INTJ",
  "User31 ENFP",
  "User32 ESTP",
  "User33 ESFJ",
  "User34 ESFJ",
  "User35 ENTP",
  "User36 ENFJ",
  "User37 ENTP",
  "User38 INTP",
  "User39 INTP",
  "User40 ISFP",
  "User41 ISFP",
  "User42 INTP",
  "User43 INTJ",
  "User44 ISTJ",
  "User45 INTP",
  "User46 INTJ",
  "User47 ENTP",
  "User48 ENTJ",
  "User49 ESFJ",
  "User50 ISFJ"
];

$userList = array();
$leaders = array();
$designers = array();
$analysts = array();
$programmers = array();
$groups = array();
$anCon = array();
$progCon = array();
$desCon = array();
$cons = array();
$container = array();
$rems = array();
$userCount = 0;
$groupCount = 0;
$memCount = 0;
$subCount = 0;
$sgCount = 0;
$anCount = 0;
$progCount = 0;
$desCount = 0;
$leadCount = 0;

function resetVariables() {
  global $userList, 
        $leaders, 
        $designers, 
        $analysts, 
        $programmers, 
        $groups, 
        $anCon, 
        $progCon, 
        $desCon, 
        $cons, 
        $container, 
        $rems, 
        $userCount, 
        $groupCount, 
        $memCount, 
        $subCount, 
        $sgCount, 
        $anCount, 
        $progCount, 
        $desCount, 
        $leadCount;

  $userList = array();
  $leaders = array();
  $designers = array();
  $analysts = array();
  $programmers = array();
  $groups = array();
  $anCon = array();
  $progCon = array();
  $desCon = array();
  $cons = array();
  $container = array();
  $rems = array();
  $userCount = 0;
  $groupCount = 0;
  $memCount = 0;
  $subCount = 0;
  $sgCount = 0;
  $anCount = 0;
  $progCount = 0;
  $desCount = 0;
  $leadCount = 0;
}

// function getUserList() {
//   global $userList, 
//           $userCount, 
//           $groupCount, 
//           $memCount, 
//           $subCount, 
//           $sgCount, 
//           $anCount, 
//           $progCount, 
//           $desCount, 
//           $leadCount;
  
//     foreach ($inputValues as $index => $content) {
//       $cont = explode(" ", $content);
//       $user = $cont[0];
//       $mbti = $cont[1];
//       $userList[] = [$user, $mbti]; // Add user and mbti to the list
//     }
  
//     $userCount = count($userList); // Get total user count
  
//     // Assuming `txt2` is accessible and has a `value` property
//     $groupCount = $txt2->value; // Assign group count
  
//     // Direct translation of calculations (may need adjustments based on your setup)
//     $memCount = floor($userCount / $groupCount);
//     $subCount = floor($memCount / 3);
//     $sgCount = $subCount * $groupCount;
//     $anCount = $sgCount;
//     $progCount = $sgCount;
//     $desCount = $sgCount;
//     $leadCount = $groupCount;
//   }

function getUserList() {
  global $userList, $userCount, $groupCount, $memCount, $subCount, $sgCount, $anCount, $progCount, $desCount, $leadCount;

  foreach ($inputValues as $index => $content) {
      $cont = explode(" ", $content);
      $user = $cont[0];
      $mbti = $cont[1];
      $userList[] = array($user, $mbti); // Add user and mbti to the list
  }

  $userCount = count($userList); // Get total user count

  // Assuming `txt2` is accessible and has a `value` property
  $groupCount = $txt2->value; // Assign group count

  // Direct translation of calculations (may need adjustments based on your setup)
  $memCount = floor($userCount / $groupCount);
  $subCount = floor($memCount / 3);
  $sgCount = $subCount * $groupCount;
  $anCount = $sgCount;
  $progCount = $sgCount;
  $desCount = $sgCount;
  $leadCount = $groupCount;
}

function getLeader() {
  global $leadPrio, $userList, $leaders, $leadCount;

  foreach ($leadPrio as $i) {
      foreach ($userList as list($x, $y)) {
          if ($y === $i && count($leaders) < $leadCount) {
              $cont1 = [$x, $y, "Lead Designer / Group Leader"];
              $leaders[] = $cont1;
          }
      }
  }

  $userList = array_filter($userList, function ($user) use ($leaders) {
      foreach ($leaders as $leader) {
          if ($leader[0] === $user[0] && $leader[1] === $user[1]) {
              return false;
          }
      }
      return true;
  });
}

function getAnalyst() {
  global $anPrio, $userList, $analysts, $sgCount;

  foreach ($anPrio as list($i, $z)) {
      foreach ($userList as list($x, $y)) {
          if (($y === $i || $y === $z) && count($analysts) < $sgCount) {
              $cont1 = [$x, $y, "Analyst"];
              $analysts[] = $cont1;
          }
      }
  }

  if (count($analysts) < $sgCount) {
      foreach ($userList as list($x, $y)) {
          if (count($programmers) === count($analysts)) {
              continue;
          }
          $cont1 = [$x, $y, "Analyst"];
          $analysts[] = $cont1;
      }
  }

  $userList = array_filter($userList, function ($user) use ($analysts) {
      foreach ($analysts as $analyst) {
          if ($analyst[0] === $user[0] && $analyst[1] === $user[1]) {
              return false;
          }
      }
      return true;
  });
}

function getProgrammer() {
  global $progPrio, $userList, $programmers, $sgCount, $progCount, $leaders, $analysts;

  foreach ($progPrio as list($i)) {
      foreach ($userList as list($x, $y)) {
          if (in_array($y, $i) && count($programmers) < $sgCount) {
              $cont1 = [$x, $y, "Programmer"];
              $programmers[] = $cont1;
          }
      }
  }

  $progCount -= count($leaders);
  $userList = array_filter($userList, function ($user) use ($programmers) {
      foreach ($programmers as $programmer) {
          if ($programmer[0] === $user[0]) {
              return false;
          }
      }
      return true;
  });

  if (count($programmers) < $sgCount && count($programmers) !== count($analysts)) {
      foreach ($userList as list($x, $y)) {
          if (count($programmers) === count($analysts)) {
              continue;
          }
          $cont1 = [$x, $y, "Programmer"];
          $programmers[] = $cont1;
      }
  }
  $userList = array_filter($userList, function ($user) use ($programmers) {
      foreach ($programmers as $programmer) {
          if ($programmer[0] === $user[0] && $programmer[1] === $user[1]) {
              return false;
          }
      }
      return true;
  });
}

function getConflict() {
  global $confPrio, $analysts, $programmers, $userList, $container, $cons;

  foreach ($confPrio as $con) {
      foreach ($analysts as list($user, $mbti, $role)) {
          if ($mbti === $con) {
              $cont = [$user, $mbti, $role];
              $container[] = $cont;
          }
      }
      $analysts = array_filter($analysts, function ($user) use ($container) {
          foreach ($container as $x) {
              if ($x[0] === $user[0]) {
                  return false;
              }
          }
          return true;
      });

      foreach ($programmers as list($user, $mbti, $role)) {
          if ($mbti === $con) {
              $cont = [$user, $mbti, $role];
              $container[] = $cont;
          }
      }
      $programmers = array_filter($programmers, function ($user) use ($container) {
          foreach ($container as $x) {
              if ($x[0] === $user[0]) {
                  return false;
              }
          }
          return true;
      });

      foreach ($userList as list($user, $mbti)) {
          if ($mbti === $con) {
              $cont = [$user, $mbti, "FOR DISTRIBUTION"];
              $container[] = $cont;
          }
      }
      $userList = array_filter($userList, function ($user) use ($container) {
          foreach ($container as $x) {
              if ($x[0] === $user[0]) {
                  return false;
              }
          }
          return true;
      });
  }

  // Create a dictionary to group users by MBTI
  $mbti_dict = [];
  foreach ($container as $user) {
      [$username, $mbti, $role] = $user;
      if (array_key_exists($mbti, $mbti_dict)) {
          $mbti_dict[$mbti][] = [$username, $mbti, $role];
      } else {
          $mbti_dict[$mbti] = [[$username, $mbti, $role]];
      }
  }
  $cons = array_values($mbti_dict);
}

function distributeLeader() {
  global $leaders, $groups;

  foreach ($leaders as $x) {
      $groups[] = [$x];
  }

  $leaders = []; // Clear the leaders array
}

function getLeadAnalyst() {
  global $leadPrio, $analysts, $leaders, $leadCount;

  foreach ($leadPrio as $i) {
      foreach ($analysts as $user) {
          [$x, $y, $z] = $user;
          if ($y === $i && count($leaders) < $leadCount) {
              $cont1 = [$x, $y, "Lead Analyst"];
              $leaders[] = $cont1;
          }
      }
  }

  $analysts = array_filter($analysts, function ($user) use ($leaders) {
      foreach ($leaders as $leader) {
          if ($leader[0] === $user[0]) {
              return false;
          }
      }
      return true;
  });
}

function distributeLeadAnalyst() {
  global $leaders, $groups, $groupCount;

  $length = count($leaders);
  $append = 0;
  $group = 1;

  foreach ($leaders as $user) {
      if ($group < $groupCount) {
          $groups[$group - 1][] = $user;
          $group += 1;
      } else {
          $groups[$group - 1][] = $user;
          $group = 0;
      }
      $append += 1;
  }

  if ($length === $append) {
      $leaders = []; // Clear the leaders array
  }
}

function getLeadProgrammer() {
  global $leadPrio, $programmers, $leaders, $leadCount;

  foreach ($leadPrio as $i) {
      foreach ($programmers as $user) {
          [$x, $y, $z] = $user;
          if ($y === $i && count($leaders) < $leadCount) {
              $cont1 = [$x, $y, "Lead Programmer"];
              $leaders[] = $cont1;
          }
      }
  }

  $programmers = array_filter($programmers, function ($user) use ($leaders) {
      foreach ($leaders as $leader) {
          if ($leader[0] === $user[0]) {
              return false;
          }
      }
      return true;
  });
}

function distributeLeadProgrammer() {
  global $leaders, $groups, $groupCount;

  $length = count($leaders);
  $append = 0;
  $group = 1;

  foreach ($leaders as $user) {
      if ($group < $groupCount) {
          $groups[$group - 1][] = $user;
          $group++;
      } else {
          $groups[$group - 1][] = $user;
          $group = 0;
      }
      $append++;
  }

  if ($length === $append) {
      $leaders = []; // Clears the leaders array
  }
}

function distributeAnalyst() {
  global $analysts, $groups, $groupCount;

  $length = count($analysts);
  $append = 0;
  $group = 0;

  foreach ($analysts as $user) {
      if ($group < $groupCount - 1) {
          $groups[$group][] = $user;
          $group++;
      } elseif ($group === $groupCount - 1) {
          $groups[$group][] = $user;
          $group = 0;
      }
      $append++;
  }

  if ($length === $append) {
      $analysts = []; // Clears the analysts array
  }
}

function distributeProgrammer() {
  global $programmers, $groups, $groupCount;

  $length = count($programmers);
  $append = 0;
  $group = 0;

  foreach ($programmers as $user) {
      if ($group < $groupCount - 1) {
          $groups[$group][] = $user;
          $group++;
      } elseif ($group === $groupCount - 1) {
          $groups[$group][] = $user;
          $group = 0;
      }
      $append++;
  }

  if ($length === $append) {
      $programmers = []; // Clears the programmers array
  }
}

function sortCon() {
  global $cons, $anCon, $progCon, $desCon, $Acount, $Pcount;

  $count = 0;
  $users = 0;

  foreach ($cons as $mbtiGroup) {
      foreach ($mbtiGroup as $user) {
          $users++;
          if ($user[2] === "Analyst") {
              $anCon[] = $user;
              $count++;
          } elseif ($user[2] === "Programmer") {
              $progCon[] = $user;
              $count++;
          } elseif ($user[2] === "FOR DISTRIBUTION") {
              $desCon[] = $user;
              $count++;
          }
      }
  }

  $Acount = count($anCon);
  $Pcount = count($progCon);
}

function roleCon() {
  global $cons, $anCon, $progCon, $groupCount, $userList, $analysts, $programmers, $Acount, $Pcount;

  $enfp = 0;
  $infp = 0;
  $estp = 0;
  $istp = 0;
  $isfp = 0;
  $esfp = 0;

  // Filter userList to remove users in groups
  $userList = array_map(function ($userList) use ($groups) {
      return array_filter($userList, function ($user) use ($groups) {
          foreach ($groups as $group) {
              if ($group[0] === $user[0]) {
                  return false;
              }
          }
          return true;
      });
  }, $userList);

  $userList = array_filter($userList, function ($user) use ($analysts) {
      foreach ($analysts as $analyst) {
          if ($analyst[0] === $user[0]) {
              return false;
          }
      }
      return true;
  });

  $userList = array_filter($userList, function ($user) use ($programmers) {
      foreach ($programmers as $programmer) {
          if ($programmer[0] === $user[0]) {
              return false;
          }
      }
      return true;
  });

  if ($Acount > $groupCount) {
      foreach ($anCon as $user) {
          if ($user[1] === "ENFP") {
              $enfp++;
          } elseif ($user[1] === "INFP") {
              $infp++;
          }
      }
  }

  if ($Pcount > $groupCount) {
      foreach ($progCon as $user) {
          switch ($user[1]) {
              case "ESTP":
                  $estp++;
                  break;
              case "ISTP":
                  $istp++;
                  break;
              case "ISFP":
                  $isfp++;
                  break;
              case "ESFP":
                  $esfp++;
                  break;
          }
      }
  }

  $enfpCount = $enfp;
  $infpCount = $infp;

  if ($enfpCount > $groupCount) {
      foreach ($anPrio as list($i, $z)) {
          foreach ($cons as list($x, $y)) {
              if (($y === $i || $y === $z) && $y !== "ENFP" && $y !== "INFP" && $enfpCount > $groupCount) {
                  $index = $enfpCount - 1;
                  $cont1 = [$x, $y, "Analyst"];
                  $anCon[] = $cont1;
                  array_splice($anCon, $index, 1);
                  $enfpCount--;
              }
          }
      }

      $userList = array_filter($userList, function ($user) use ($analysts) {
          foreach ($analysts as $analyst) {
              if ($analyst[0] === $user[0]) {
                  return false;
              }
          }
          return true;
      });
  }

  if ($infpCount > $groupCount) {
      foreach ($anPrio as list($i, $z)) {
          foreach ($cons as list($x, $y)) {
              if (($y === $i || $y === $z) && $y !== "ENFP" && $y !== "INFP" && $infpCount > $groupCount) {
                  $index = $infpCount - 1;
                  $cont1 = [$x, $y, "Analyst"];
                  $anCon[] = $cont1;
                  array_splice($anCon, $index, 1);
                  $infpCount--;
              }
          }
      }

      $userList = array_filter($userList, function ($user) use ($analysts) {
          foreach ($analysts as $analyst) {
              if ($analyst[0] === $user[0]) {
                  return false;
              }
          }
          return true;
      });
  }

  $estpCount = $estp;
  $istpCount = $istp;
  $isfpCount = $isfp;
  $esfpCount = $esfp;

  if ($estpCount > $groupCount) {
      foreach ($progPrio as $i) {
          foreach ($cons as list($x, $y)) {
              if ($y === $i && $y !== "ESTP" && $estpCount > $groupCount) {
                  $index = $estpCount - 1;
                  $cont1 = [$x, $y, "Programmer"];
                  $progCon[] = $cont1;
                  array_splice($progCon, $index, 1);
                  $estpCount--;
              }
          }
      }
  }
  if ($istpCount > $groupCount) {
      foreach ($progPrio as $i) {
          foreach ($cons as list($x, $y)) {
              if ($y === $i && $y !== "ESTP" && $istpCount > $groupCount) {
                  $index = $istpCount - 1;
                  $cont1 = [$x, $y, "Programmer"];
                  $progCon[] = $cont1;
                  array_splice($progCon, $index, 1);
                  $istpCount--;
              }
          }
      }
  }
  if ($isfpCount > $groupCount) {
      foreach ($progPrio as $i) {
          foreach ($cons as list($x, $y)) {
              if ($y === $i && $y !== "ESTP" && $isfpCount > $groupCount) {
                  $index = $isfpCount - 1;
                  $cont1 = [$x, $y, "Programmer"];
                  $progCon[] = $cont1;
                  array_splice($progCon, $index, 1);
                  $isfpCount--;
              }
          }
      }
  }
  if ($esfpCount > $groupCount) {
      foreach ($progPrio as $i) {
          foreach ($cons as list($x, $y)) {
              if ($y === $i && $y !== "ESTP" && $esfpCount > $groupCount) {
                  $index = $esfpCount - 1;
                  $cont1 = [$x, $y, "Programmer"];
                  $progCon[] = $cont1;
                  array_splice($progCon, $index, 1);
                  $esfpCount--;
              }
          }
      }
  }

  $filteredCons = [];
  $append = 0;

  for ($mbti = 0; $mbti < count($cons); $mbti++) {
      // Removes anCon users from cons list and appends them to filteredCons
      for ($ind = 0; $ind < count($cons[$mbti]); $ind++) {
          $append = 0;
          for ($anuser = 0; $anuser < count($anCon); $anuser++) {
              if ($append === 0) {
                  if ($ind <= $anuser) {
                      if ($cons[$mbti][$ind] === $anCon[$anuser]) {
                          break;
                      } else {
                          $filteredCons[] = $cons[$mbti][$ind];
                          $append = 1;
                      }
                  }
              }
          }
      }
  }

  $append = 0;
  $refilteredCons = [];

  for ($ind = 0; $ind < count($filteredCons); $ind++) {
      // Removes progCon users from cons list and appends them to refilteredCons
      $append = 0;
      for ($anuser = 0; $anuser < count($progCon); $anuser++) {
          if ($append === 0) {
              if ($ind <= $anuser) {
                  if ($filteredCons[$ind] === $progCon[$anuser]) {
                      break;
                  } else {
                      $refilteredCons[] = $filteredCons[$ind];
                      $append = 1;
                  }
              } elseif ($ind > count($progCon) - 1) {
                  $refilteredCons[] = $filteredCons[$ind];
                  $append = 1;
              }
          }
      }
  }

  $cons = $refilteredCons; // Updates cons to the value of refilteredCons
}

function getDesigner() {
  global $desPrio, $userList, $designers, $sgCount, $leadCount;

  $append = 0;
  foreach ($desPrio as $i) {
      foreach ($userList as list($x, $y)) {
          if (count($designers) < $sgCount - $leadCount) {
              if ($append <= count($userList) - 1) {
                  $cont1 = [$x, $y, "Designer"];
                  $designers[] = $cont1;
                  $append++;
              }
          }
      }
  }

  $userList = array_filter($userList, function ($user) use ($designers) {
      foreach ($designers as $designer) {
          if ($user[0] === $designer[0]) {
              return false;
          }
      }
      return true;
  });
}

function distributeDesigner() {
  global $designers, $groups, $groupCount;

  $length = count($designers);
  $append = 0;
  $group = 0;

  for ($i = 0; $i < $length; $i++) {
      if ($group < $groupCount - 1) {
          $groups[$group][] = $designers[$i];
          $group++;
      } elseif ($group === $groupCount - 1) {
          $groups[$group][] = $designers[$i];
          $group = 0;
      }
      $append++;
  }

  if ($length === $append) {
      $designers = [];
  }
}

function distribute_anCon() {
  global $anCon, $groups, $subCount;

  foreach ($anCon as $user) {
      $append = 0;
      foreach ($groups as &$group) {
          $counter = 0;
          if ($append === 0) {
              foreach ($group as $user1) {
                  if ($user1[2] === "Analyst" || $user1[2] === "Lead Analyst") {
                      $counter += 1;
                  }
              }
              if ($append === 0) {
                  if ($counter < $subCount) {
                      $group[] = $user;
                      $counter += 1;
                      $append = 1;
                  }
              }
          }
      }
  }

  // Remove users from anCon if they are added to groups
  $anCon = array_map(function ($userList) use ($groups) {
      return array_filter($userList, function ($user) use ($groups) {
          foreach ($groups as $group) {
              if ($group[0][0] === $user[0]) {
                  return false;
              }
          }
          return true;
      });
  }, $anCon);
}

function distribute_progCon() {
  global $progCon, $groups, $subCount;

  foreach ($progCon as $user) {
      $append = 0;
      foreach ($groups as &$group) {
          $counter = 0;
          if ($append === 0) {
              foreach ($group as $user1) {
                  if ($user1[2] === "Programmer" || $user1[2] === "Lead Programmer") {
                      $counter += 1;
                  }
              }
              if ($append === 0) {
                  if ($counter < $subCount) {
                      $group[] = $user;
                      $counter += 1;
                      $append = 1;
                  }
              }
          }
      }
  }

  // Remove users from progCon if they are added to groups
  $progCon = array_map(function ($userList) use ($groups) {
      return array_filter($userList, function ($user) use ($groups) {
          foreach ($groups as $group) {
              if ($group[0][0] === $user[0]) {
                  return false;
              }
          }
          return true;
      });
  }, $progCon);
}

function distribute_desCon() {
  global $desCon, $groups, $subCount, $cons;

  foreach ($desCon as [$user, $mbti, $role]) {
      $append = 0;
      foreach ($groups as &$group) {
          $counter = 0;
          if ($append === 0) {
              foreach ($group as $user1) {
                  if ($user1[2] === "Designer" || $user1[2] === "Lead Designer / Group Leader") {
                      $counter += 1;
                  }
              }
              if ($append === 0) {
                  if ($counter < $subCount) {
                      $cont = [$user, $mbti, "Designer"];
                      $group[] = $cont;
                      $counter += 1;
                      $append = 1;
                  }
              }
          }
      }
  }

  // Remove users from cons if they are added to groups
  $cons = array_map(function ($userList) use ($groups) {
      return array_filter($userList, function ($user) use ($groups) {
          foreach ($groups as $group) {
              if ($group[0][0] === $user[0]) {
                  return false;
              }
          }
          return true;
      });
  }, $cons);
}

function countRems() {
  global $userList, $cons, $leaders, $designers, $analysts, $programmers, $anCon, $progCon, $desCon, $rems, $groupCount;

  // will count excess users (if there are remainders)
  $arrList = [
      $userList,
      $cons,
      $leaders,
      $designers,
      $analysts,
      $programmers,
      $anCon,
      $progCon,
      $desCon,
  ];
  $x = $groupCount;
  foreach ($arrList as $arr) {
      if (!empty($arr)) {
          foreach ($arr as $user) {
              if (!empty($user)) {
                  $rems[] = [$user[0], $user[1]];
              }
          }
      }
  }
}

function disRem() {
  global $groups, $rems;

  $i = 0;

  foreach ($groups as $group) {
      $ind = (int)$group;
      foreach ($rems as $user) {
          if ($i > array_search($user, $rems) && $i !== 0) {
              continue;
          }
          $userN = [$user[0], $user[1], "Designer"];
          $groups[$ind][] = $userN;
          $i++;
          break;
      }
  }
}

function main() {
  global $groups;

  getUserList();

  getLeader();
  distributeLeader();

  getAnalyst();
  getProgrammer();

  getLeadAnalyst();
  distributeLeadAnalyst();

  getLeadProgrammer();
  distributeLeadProgrammer();

  getConflict();

  distributeAnalyst();
  distributeProgrammer();

  sortCon();
  roleCon();

  getDesigner();
  distributeDesigner();

  distribute_anCon();
  distribute_progCon();
  distribute_desCon();

  countRems();
  disRem();

  // Output the result
  // createResultTables($groups);
  // resetVariables();
}

// Assuming btn1 is the button and main() is the click event handler
$btn1->on('click', 'main');

