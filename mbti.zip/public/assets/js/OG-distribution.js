// *****************************************
//      DISTRIBUTION, INPUT & OUTPUT
// *****************************************


const leadPrio = [
  "ESTJ",
  "ISTJ",
  "ENTJ",
  "INTJ",
  "ENTP",
  "INTP",
  "ESFJ",
  "ENFJ",
  "ISFJ",
  "INFJ",
  "ENFP",
  "ESTP",
  "ISTP",
  "INFP",
  "ISFP",
  "ESFP",
];

const confPrio = ["ENFP", "ESTP", "ISTP", "INFP", "ISFP", "ESFP"];

const anPrio = [
  ["ENFJ", "ENFP"],
  ["ENTJ", "ENTP"],
  ["INFJ", "INFP"],
  ["INTJ", "INTP"],
];

const progPrio = [
  "ISTJ",
  "INTJ",
  "ESTJ",
  "ISTP",
  "ESTP",
  "ISFJ",
  "ESFJ",
  "ISFP",
  "ESFP",
];

const desPrio = [
  ["INTJ", "INTP", "ENTJ", "ENTP"],
  ["ISTJ", "ISFJ", "ESTJ", "ESFJ"],
  "ISTP",
  ["INFJ", "INFP", "ENFJ", "ENFP", "ISFP", "ESTP", "ESFP"],
];

// const txt2 = document.getElementById("group");
const txt2 = document.getElementById("num-of-groups");
const btn1 = document.getElementById("btn1");
const out1 = document.getElementById("output1");

//let inputValues = document.getElementById

   let inputValues = ["User1 ENFP","User2 INTP","User3 ENFJ","User4 ENFJ","User5 ENTJ","User6 ENFJ","User7 ISFJ","User8 ENFP","User9 ENFP","User10 ENTJ","User11 ISFJ","User12 ESFJ","User13 ENTP","User14 ESTJ","User15 ESTJ","User16 ESFJ","User17 INTP","User18 ENFP","User19 INFJ","User20 ISFP","User21 INFP","User22 ESFJ","User23 ISTP","User24 ESFJ","User25 ISTJ","User26 ENTJ","User27 ENFP","User28 ISFJ","User29 ESTJ","User30 INTJ","User31 ENFP","User32 ESTP","User33 ESFJ","User34 ESFJ","User35 ENTP","User36 ENFJ","User37 ENTP","User38 INTP","User39 INTP","User40 ISFP","User41 ISFP","User42 INTP","User43 INTJ","User44 ISTJ","User45 INTP","User46 INTJ","User47 ENTP","User48 ENTJ","User49 ESFJ","User50 ISFJ"];
  // let inputValues = ["12345678901 ENFP",
  //       "23456789012 INTP",
  //       "34567890123 ENFJ",
  //       "45678901234 ENFJ",
  //       "56789012345 ENTJ",
  //       "67890123456 ENFJ",
  //       "78901234567 ISFJ",
  //       "89012345678 ENFP",
  //       "90123456789 ENFP",
  //       "01234567890 ENTJ",
  //       "12345678901 ISFJ",
  //       "23456789012 ESFJ",
  //       "34567890123 ENTP",
  //       "45678901234 ESTJ",
  //       "56789012345 ESTJ",
  //       "67890123456 ESFJ",
  //       "78901234567 INTP",
  //       "89012345678 ENFP",
  //       "90123456789 INFJ",
  //       "01234567890 ISFP",
  //       "12345678901 INFP",
  //       "23456789012 ESFJ",
  //       "34567890123 ISTP",
  //       "45678901234 ESFJ",
  //       "56789012345 ISTJ",
  //       "67890123456 ENTJ",
  //       "78901234567 ENFP",
  //       "89012345678 ISFJ",
  //       "90123456789 ESTJ",
  //       "01234567890 INTJ",
  //       "12345678901 ENFP",
  //       "23456789012 ESTP",
  //       "34567890123 ESFJ",
  //       "45678901234 ESFJ",
  //       "56789012345 ENTP",
  //       "67890123456 ENFJ",
  //       "78901234567 ENTP",
  //       "89012345678 INTP",
  //       "90123456789 INTP",
  //       "01234567890 ISFP",
  //       "12345678901 ISFP",
  //       "23456789012 INTP",
  //       "34567890123 INTJ",
  //       "45678901234 ISTJ",
  //       "56789012345 INTP",
  //       "67890123456 INTJ",
  //       "78901234567 ENTP",
  //       "89012345678 ENTJ",
  //       "90123456789 ESFJ",
  //       "01234567890 ISFJ"];

let userCopy = [];


let groupsCopy = [];

let userList = [];
let leaders = [];
let designers = [];
let analysts = [];
let programmers = [];
let groups = [];
let anCon = [];
let progCon = [];
let desCon = [];
let cons = [];
let container = [];
let rems = [];
let userCount = 0;
let groupCount = 0;
let memCount = 0;
let subCount = 0;
let sgCount = 0;
let anCount = 0;
let progCount = 0;
let desCount = 0;
let leadCount = 0;

function resetVariables() {
  userList = [];
  leaders = [];
  designers = [];
  analysts = [];
  programmers = [];
  groups = [];
  anCon = [];
  progCon = [];
  desCon = [];
  cons = [];
  container = [];
  rems = [];
  userCount = 0;
  groupCount = 0;
  memCount = 0;
  subCount = 0;
  sgCount = 0;
  anCount = 0;
  progCount = 0;
  desCount = 0;
  leadCount = 0;
}


function conlog(){
  console.log('')
  console.log('start')
  console.log('userCount =', userCount)
  console.log('groupCount = ', groupCount)
  console.log('memCount = ', memCount)
  console.log('subCount = ', subCount)
  console.log('sgCount = ', sgCount)
  console.log('leaders', leaders)
  console.log('userlist', userList)
  console.log('analysts', analysts)
  console.log('programmers', programmers)
  console.log('conflicts', cons)
  console.log('groups', groups)
  console.log('desCon', desCon)
  console.log('remainders', rems)
  console.log('end')
}


// ****************************************************************************
//                    START OF MAIN DISTRIBUTION SYSTEM

function getuserList() {
  const arr1 = inputValues;
  console.log(arr1);

  for (index in arr1) {
    let cont = arr1[index].split(" ");
    let user = cont[0];
    let mbti = cont[1];
    userList.push([user, mbti]);
  }

  userCount = userList.length;
  groupCount = txt2.value;
  memCount = Math.floor(userCount / groupCount);
  subCount = Math.floor(memCount / 3);
  sgCount = subCount * groupCount;
  anCount = sgCount;
  progCount = sgCount;
  desCount = sgCount;
  leadCount = groupCount;

  // conlog();
}

function getLeader() {
  for (let i of leadPrio) {
    for (let [x, y] of userList) {
      if (y === i && leaders.length < leadCount) {
        let cont1 = [x, y, "Lead Designer / Group Leader"];
        leaders.push(cont1);
      }
    }
  }

  userList = userList.filter(
    (user) =>
      !leaders.some((leader) => leader[0] === user[0] && leader[1] === user[1])
  );

  // conlog();


}

function getAnalyst() {
  for (let [i, z] of anPrio) {
    for (let [x, y] of userList) {
      if ((y === i || y === z) && analysts.length < sgCount) {
        let cont1 = [x, y, "Analyst"];
        analysts.push(cont1);
      }
    }
  }

  if (analysts.length < sgCount) {
    for (let [x, y] of userList) {
      if (programmers.length === analysts.length) {
        continue;
      }
      let cont1 = [x, y, "Analyst"];
      analysts.push(cont1);
    }
  }

  userList = userList.filter(
    (user) =>
      !analysts.some(
        (analysts) => analysts[0] === user[0] && analysts[1] === user[1]
      )
  );
  // conlog();

}

function getProgrammer() {
  for (let [i] of progPrio) {
    for (let [x, y] of userList) {
      if (i.includes(y) && programmers.length < sgCount) {
        let cont1 = [x, y, "Programmer"];
        programmers.push(cont1);
      }
    }
  }

  progCount = progCount - leaders.length;
  userList = userList.filter(
    (user) => !programmers.some((programmer) => programmer[0] === user[0])
  );

  if (programmers.length < sgCount && programmers.length !== analysts.length) {
    for (let [x, y] of userList) {
      if (programmers.length === analysts.length) {
        continue;
      }
      let cont1 = [x, y, "Programmer"];
      programmers.push(cont1);
    }
  }
  userList = userList.filter(
    (user) =>
      !programmers.some(
        (programmers) =>
          programmers[0] === user[0] && programmers[1] === user[1]
      )
  );
  // console.log('===========================================');
  // conlog();
  // console.log('===========================================');
}

function getConflict() {
  for (let con of confPrio) {
    for (let [user, mbti, role] of analysts) {
      if (mbti === con) {
        let cont = [user, mbti, role];
        container.push(cont);
      }
    }
    analysts = analysts.filter(
      (user) => !container.some((x) => x[0] === user[0])
    );

    console.log('(((((((((((((((((((((((((((((((((((((((((((((((((((');
    console.log('FILTERED ANAL');
    console.log(analysts);
    console.log('(((((((((((((((((((((((((((((((((((((((((((((((((((');
    for (let [user, mbti, role] of programmers) {
      if (mbti === con) {
        let cont = [user, mbti, role];
        container.push(cont);
      }
    }
    programmers = programmers.filter(
      (user) => !container.some((x) => x[0] === user[0])
    );
    console.log('))))))))))))))))))))))))))))))))))))))))))))))))))');
    console.log('FILTERED PROG');
    console.log(programmers);
    console.log('))))))))))))))))))))))))))))))))))))))))))))))))))');

    for (let [user, mbti] of userList) {
      if (mbti === con) {
        let cont = [user, mbti, "FOR DISTRIBUTION"];
        container.push(cont);
      }
    }
    userList = userList.filter(
      (user) => !container.some((x) => x[0] === user[0])
    );
  }





  // Create a dictionary to group users by MBTI
  let mbti_dict = {};
  for (let user of container) {
    let username = user[0],
      mbti = user[1],
      role = user[2];
    if (mbti in mbti_dict) {
      mbti_dict[mbti].push([username, mbti, role]);
    } else {
      mbti_dict[mbti] = [[username, mbti, role]];
    }
  }
  cons = Object.values(mbti_dict);
  // console.log('(((((((((((((((((((((((((((((((((((((((((((((((((((');
  // console.log(container);
  // console.log('(((((((((((((((((((((((((((((((((((((((((((((((((((');
  // // conlog();
  // console.log('))))))))))))))))))))))))))))))))))))))))))))))))))');
  // console.log(cons);
  // console.log('))))))))))))))))))))))))))))))))))))))))))))))))))');
}
function distributeLeader() {
  for (let x of leaders) {
    groups.push([x]);
    // console.log(x);
  }

  leaders.length = 0; // Clear the leaders array
  // conlog();
}

function getLeadAnalyst() {
  for (let i of leadPrio) {
    for (let user of analysts) {
      let [x, y, z] = user;
      if (y === i && leaders.length < leadCount) {
        let cont1 = [x, y, "Lead Analyst"];
        leaders.push(cont1);
      }
    }
  }

  analysts = analysts.filter(
    (user) => !leaders.some((leader) => leader[0] === user[0])
  );
}

function distributeLeadAnalyst() {
  let length = leaders.length;
  let append = 0;
  let group = 1;

  for (let user of leaders) {
    if (group < groupCount) {
      groups[group - 1].push(user);
      group += 1;
    } else {
      groups[group - 1].push(user);
      group = 0;
    }
    append += 1;
  }

  if (length === append) {
    leaders.length = 0; // Clear the leaders array
  }
  // conlog();
}

function getLeadProgrammer() {
  for (let i of leadPrio) {
    for (let user of programmers) {
      let [x, y, z] = user;
      if (y === i && leaders.length < leadCount) {
        let cont1 = [x, y, "Lead Programmer"];
        leaders.push(cont1);
      }
    }
  }

  programmers = programmers.filter(
    (user) => !leaders.some((leader) => leader[0] === user[0])
  );
  // conlog();
}

function distributeLeadProgrammer() {
  const length = leaders.length;
  let append = 0;
  let group = 1;

  for (const user of leaders) {
    if (group < groupCount) {
      groups[group - 1].push(user);
      group++;
    } else {
      groups[group - 1].push(user);
      group = 0;
    }
    append++;
  }

  if (length === append) {
    leaders.length = 0; // Clears the leaders array
  }
  // conlog();
}

function distributeAnalyst() {
  const length = analysts.length;
  let append = 0;
  let group = 0;

  for (const user of analysts) {
    if (group < groupCount - 1) {
      groups[group].push(user);
      // console.log('burat');
      // console.log(user);
      group++;
    } else if (group === groupCount - 1) {
      groups[group].push(user);
      // console.log('bahog');
      // console.log(user);
      group = 0;
    }
    append++;
  }

  if (length === append) {
    analysts.length = 0; // Clears the analysts array
  }
  console.log('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
  conlog();
  console.log('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++');
}
function distributeProgrammer() {
  const length = programmers.length;
  let append = 0;
  let group = 0;

  for (const user of programmers) {
    if (group < groupCount - 1) {
      groups[group].push(user);
      // console.log('burat');
      // console.log(user);
      group++;
    } else if (group === groupCount - 1) {
      groups[group].push(user);
      // console.log('bahog');
      // console.log(user);
      group = 0;
    }
    append++;
  }

  if (length === append) {
    programmers.length = 0; // Clears the programmers array
  }
  // conlog();
}

function sortCon() {
  let count = 0;
  let users = 0;

  for (const mbtiGroup of cons) {
    for (const user of mbtiGroup) {
      users++;
      if (user[2] === "Analyst") {
        anCon.push(user);
        count++;
      } else if (user[2] === "Programmer") {
        progCon.push(user);
        count++;
      } else if (user[2] === "FOR DISTRIBUTION") {
        desCon.push(user);
        count++;
      }
    }
  }

  Acount = anCon.length;
  Pcount = progCon.length;
  console.log('=======================================================');
  console.log('SORTCON');
  console.log(anCon);
  console.log(desCon);
  console.log(progCon);
  conlog();
  console.log('=======================================================');
}

function roleCon() {
  let enfp = 0;
  let infp = 0;
  let estp = 0;
  let istp = 0;
  let isfp = 0;
  let esfp = 0;
  // conlog();
  // Filter userList to remove users in groups
  userList = userList.map((userList) =>
    userList.filter((user) => !groups.some((group) => group[0] === user[0]))
  );

  userList = userList.filter(
    (user) => !analysts.some((analyst) => analyst[0] === user[0])
  );
  userList = userList.filter(
    (user) => !programmers.some((programmer) => programmer[0] === user[0])
  );

  if (Acount > groupCount) {
    for (const user of anCon) {
      if (user[1] === "ENFP") {
        enfp++;
      } else if (user[1] === "INFP") {
        infp++;
      }
    }
  }

  if (Pcount > groupCount) {
    for (const user of progCon) {
      if (user[1] === "ESTP") {
        estp++;
      } else if (user[1] === "ISTP") {
        istp++;
      } else if (user[1] === "ISFP") {
        isfp++;
      } else if (user[1] === "ESFP") {
        esfp++;
      }
    }
  }
  // console.log('-1');
  // conlog();
  let enfpCount = enfp;
  let infpCount = infp;
  if (enfpCount > groupCount) {
    for (const [i, z] of anPrio) {
      for (const [x, y] of cons) {
        // console.log('x :', x);
        // console.log('y :',  y);
        // console.log(y == null);
        if (
          (y === i || y === z) &&
          y !== "ENFP" &&
          y !== "INFP" &&
          enfpCount > groupCount
        ) {
          index = enfpCount - 1;
          cont1 = [x, y, "Analyst"];
          anCon.push(cont1);
          anCon.splice(index, 1);
          enfpCount--;
        }
      }
    }

    userList = userList.filter(
      (user) => !analysts.some((analyst) => analyst[0] === user[0])
    );
  }
  // console.log('0');
  // conlog();


  if (infpCount > groupCount) {
    for (const [i, z] of anPrio) {
      for (const [x, y] of cons) {
        if (
          (y === i || y === z) &&
          y !== "ENFP" &&
          y !== "INFP" &&
          infpCount > groupCount
        ) {
          const index = infpCount - 1;
          const cont1 = [x, y, "Analyst"];
          anCon.push(cont1);
          anCon.splice(index, 1);
          infpCount--;
        }
      }
    }

    userList = userList.filter(
      (user) => !analysts.some((analyst) => analyst[0] === user[0])
    );
  }

  const estpCount = estp;
  const istpCount = istp;
  const isfpCount = isfp;
  const esfpCount = esfp;

  if (estpCount > groupCount) {
    for (const i of progPrio) {
      for (const [x, y] of cons) {
        if (y === i && y !== "ESTP" && estpCount > groupCount) {
          const index = estpCount - 1;
          const cont1 = [x, y, "Programmer"];
          progCon.push(cont1);
          progCon.splice(index, 1);
          estpCount--;
        }
      }
    }
  }

  if (istpCount > groupCount) {
    for (const i of progPrio) {
      for (const [x, y] of cons) {
        if (y === i && y !== "ESTP" && istpCount > groupCount) {
          const index = istpCount - 1;
          const cont1 = [x, y, "Programmer"];
          progCon.push(cont1);
          progCon.splice(index, 1);
          istpCount--;
        }
      }
    }
  }

  if (isfpCount > groupCount) {
    for (const i of progPrio) {
      for (const [x, y] of cons) {
        if (y === i && y !== "ESTP" && isfpCount > groupCount) {
          const index = isfpCount - 1;
          const cont1 = [x, y, "Programmer"];
          progCon.push(cont1);
          progCon.splice(index, 1);
          isfpCount--;
        }
      }
    }
  }

  if (esfpCount > groupCount) {
    for (const i of progPrio) {
      for (const [x, y] of cons) {
        if (y === i && y !== "ESTP" && esfpCount > groupCount) {
          const index = esfpCount - 1;
          const cont1 = [x, y, "Programmer"];
          progCon.push(cont1);
          progCon.splice(index, 1);
          esfpCount--;
        }
      }
    }
  }

  // console.log('5');
  // conlog();
  let filteredCons = [];
  let append = 0;

  for (let mbti = 0; mbti < cons.length; mbti++) {
    //removes anCon users from cons list and appends them to filteredCons
    for (let ind = 0; ind < cons[mbti].length; ind++) {
      append = 0;
      for (let anuser = 0; anuser < anCon.length; anuser++) {
        if (append === 0) {
          if (ind <= anuser) {
            if (cons[mbti][ind] === anCon[anuser]) {
              break;
            } else {
              filteredCons.push(cons[mbti][ind]);
              append = 1;
            }
          }
        }
      }
    }
  }
  // console.log('FILTERED CONS:')
  // console.log(filteredCons);

  //const cons = filteredCons //updates cons to the value of filteredCons

  //filteredCons = [];
  append = 0;

  let refilteredCons = [];

  for (let ind = 0; ind < filteredCons.length; ind++) {
    //removes progCon users from cons list and appends them to filteredCons
    append = 0;
    for (let anuser = 0; anuser < progCon.length; anuser++) {
      if (append === 0) {
        if (ind <= anuser) {
          if (filteredCons[ind] === progCon[anuser]) {
            break;
          } else {
            refilteredCons.push(filteredCons[ind]);
            append = 1;
          }
        } else if (ind > progCon.length - 1) {
          refilteredCons.push(filteredCons[ind]);
          append = 1;
        }
      }
    }
  }
  // console.log('REFILTERED CONS:')
  // console.log(refilteredCons);

  cons = refilteredCons; //updates cons to the value of refilteredCons
  conlog();
}

function getDesigner() {
  let append = 0;
  for (let i of desPrio) {
    for (let [x, y] of userList) {
      if (designers.length < sgCount - leadCount) {
        if (append <= userList.length - 1) {
          const cont1 = [x, y, "Designer"];
          designers.push(cont1);
          console.log(designers);
          append++;
        }
      }
    }
  }

  userList = userList.filter(
    (user) => !designers.some((designer) => user[0] === designer[0])
  );
  // conlog();
}

function distributeDesigner() {
  let length = designers.length;
  let append = 0;
  let group = 0;

  for (let i = 0; i < length; i++) {
    if (group < groupCount - 1) {
      groups[group].push(designers[i]);
      group++;
    } else if (group === groupCount - 1) {
      groups[group].push(designers[i]);
      group = 0;
    }
    append++;
  }

  if (length === append) {
    designers = [];
  }
  console.log('NIGGAS', groups)
  conlog();
}



function distribute_anCon() {
  for (let user of anCon) {
    let append = 0;
    for (let group of groups) {
      let counter = 0;
      if (append === 0) {
        for (let user1 of group) {
          if (user1[2] === "Analyst" || user1[2] === "Lead Analyst") {
            counter += 1;
          }
        }
        if (append === 0) {
          if (counter < subCount) {
            group.push(user);
            counter += 1;
            append = 1;
          }
        }
      }
    }
  }

  anCon = anCon.map((userList) =>
    userList.filter((user) => groups.some((group) => group[0][0] === user[0]))
  );
  // conlog();
}

function distribute_progCon() {
  for (let user of progCon) {
    let append = 0;
    for (let group of groups) {
      let counter = 0;
      if (append === 0) {
        for (let user1 of group) {
          if (user1[2] === "Programmer" || user1[2] === "Lead Programmer") {
            counter += 1;
          }
        }
        if (append === 0) {
          if (counter < subCount) {
            group.push(user);
            counter += 1;
            append = 1;
          }
        }
      }
    }
  }

  progCon = progCon.map((userList) =>
    userList.filter((user) => groups.some((group) => group[0][0] === user[0]))
  );
  // conlog();
}

function distribute_desCon() {
  for (let [user, mbti, role] of desCon) {
    let append = 0;
    for (let group of groups) {
      let counter = 0;
      if (append === 0) {
        for (let user1 of group) {
          if (
            user1[2] === "Designer" ||
            user1[2] === "Lead Designer / Group Leader"
          ) {
            counter += 1;
          }
        }
        if (append === 0) {
          if (counter < subCount) {
            const cont = [user, mbti, "Designer"];
            group.push(cont);
            counter += 1;
            append = 1;
          }
        }
      }
    }
  }

  cons = cons.map((userList) =>
    userList.filter((user) => groups.some((group) => group[0][0] === user[0]))
  );
  // conlog();
}

function countRems() {
  //will count excess users (if may remainders)
  let arrList = [
    userList,
    cons,
    leaders,
    designers,
    analysts,
    programmers,
    anCon,
    progCon,
    desCon,
  ];
  let x = groupCount;
  for (let arr of arrList) {
    if (arr.length !== 0) {
      for (let user of arr) {
        if (user.length !== 0) {
          rems.push([user[0], user[1]]);
        }
      }
    }
  }
  // conlog();
}

function disRem() {
  let i = 0;

  for (let group in groups) {
    let ind = parseInt(group);
    for (let user of rems) {
      if (i > rems.indexOf(user) && i !== 0) {
        continue;
      }
      let userN = [user[0], user[1], "Designer"];
      groups[ind].push(userN);
      i++;
      break;
    }
  }
}



//                    END OF MAIN DISTRIBUTION SYSTEM
// ****************************************************************************


// ***********************
// *    MAIN FUNCTION    *
// ***********************

function main() {
  getuserList();

  if (groupCount > userCount) {
    alert("Number of Groups can't be more than the Total number of Students!");
  } else {
  getLeader();
  distributeLeader();

  getAnalyst();
  getProgrammer();

  getLeadAnalyst();
  distributeLeadAnalyst();

  getLeadProgrammer();
  distributeLeadProgrammer();

  getConflict();

  distributeAnalyst();
  distributeProgrammer();

  sortCon();
  roleCon();

  getDesigner();
  distributeDesigner();

  distribute_anCon();
  distribute_progCon();
  distribute_desCon();

  countRems();
  disRem();

  groupsCopy = [...groups];
  console.log('FUCKINGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG',typeof groups);
  console.log('NIGGASANAYO', groupsCopy);
  out1.innerHTML = groups
  // console.log(groups);

  // createResultTables(groups);
  resetVariables()
  }
}



btn1.addEventListener("click", main);

function grouped() {  
  let jsonGroups = JSON.stringify(groupsCopy);

  document.getElementById("grouped").value = jsonGroups;
  document.getElementById("groupings").submit();
}
